#!/usr/bin/env python3
"""Generate real gcov-based line/function/branch/decision coverage metrics.

Decision coverage is reported as the percentage of source-line decision groups
for which every recorded branch outcome was exercised. This is intentionally
labeled as a gcov-derived decision metric rather than pretending it is a
compiler-standard ISO metric.
"""
from __future__ import annotations
import re
import subprocess
import sys
from pathlib import Path

THRESHOLD = 95.0
# Only the application entry point is excluded: main.cpp is wiring/argv
# handling exercised by running the real binary, not unit tests, and it
# is deliberately kept out of the edge_iot_core library target for that
# reason (see root CMakeLists.txt). mqtt_client.cpp needs no special
# case here — it is only compiled (and therefore only produces a .gcov
# file at all) when Paho MQTT was found on the system; when it's absent
# it simply never appears in `files` below.
#
# Previously this script also hid database_manager.cpp,
# resource_controller.cpp, task_executor.cpp, logger.cpp,
# simulation_config.cpp, task_manager.cpp, iot_device.cpp,
# sensor_simulator.cpp, and resource_monitor.cpp behind an
# INCLUDED_MODULES allowlist, so the "95%" this reported was only ever
# 6 of 17 source files' coverage, not the project's. That allowlist has
# been removed so this number now reflects the whole codebase.
EXCLUDED = {"main.cpp"}


def run_gcov(build: Path) -> list[Path]:
    for gcov_file in build.glob("*.gcov"):
        gcov_file.unlink(missing_ok=True)
    for gcda in build.rglob("*.gcda"):
        objdir = gcda.parent
        cmd = ["gcov", "-b", "-c", "-p", "-o", str(objdir), str(gcda)]
        proc = subprocess.run(cmd, cwd=build, text=True, capture_output=True)
        if proc.returncode != 0:
            print(proc.stdout, end="")
            print(proc.stderr, end="", file=sys.stderr)
            continue
        # gcov writes *.gcov into cwd. Track files created/updated by this run.
    return list(build.glob("*.gcov"))


def parse_gcov(path: Path) -> tuple[int, int, int, int, int, int, int, int]:
    text = path.read_text(errors="replace").splitlines()
    source = ""
    for line in text:
        if ":Source:" in line:
            source = line.split(":Source:", 1)[1].strip()
            break
    source_path = Path(source)
    normalized_source = source.replace("\\", "/")
    if source_path.name in EXCLUDED or ("/src/" not in normalized_source and not normalized_source.startswith("src/") and "../src/" not in normalized_source):
        return (0,) * 8

    line_total = line_covered = 0
    function_total = function_covered = 0
    branch_total = branch_covered = 0
    decision_total = decision_covered = 0

    # Count executable source lines directly from the gcov detail output so
    # the numerator/denominator are not reconstructed from a rounded percent.
    for line in text:
        lm = re.match(r"\s*([^:]+):\s*(\d+):", line)
        if lm:
            count = lm.group(1).strip()
            if count not in {"-", ""} and not count.startswith("===="):
                line_total += 1
                try:
                    if int(count) > 0:
                        line_covered += 1
                except ValueError:
                    if count.startswith("*") or count not in {"#####", "-"}:
                        line_covered += 1
        m = re.search(r"function .* called (\d+)", line)
        if m:
            function_total += 1
            if int(m.group(1)) > 0:
                function_covered += 1
        m = re.search(r"branch\s+\d+ taken ([^\s]+)", line)
        if m:
            branch_total += 1
            token = m.group(1).strip()
            try:
                taken = float(token)
                if taken > 0:
                    branch_covered += 1
            except ValueError:
                if token not in {"0", "0.0", "0%"}:
                    branch_covered += 1

    # A decision is represented by one or more consecutive branch records after
    # the same numbered source line. Count a decision covered only when every
    # outcome is taken at least once.
    current_branches: list[bool] = []
    current_source_line = None
    decisions: list[tuple[int, bool]] = []
    for line in text:
        src = re.match(r"\s*[^:]+:\s*(\d+):", line)
        if src:
            if current_branches and current_source_line is not None:
                decisions.append((current_source_line, all(current_branches)))
            current_source_line = int(src.group(1))
            current_branches = []
        bm = re.search(r"branch\s+\d+ taken ([^\s]+)", line)
        if bm:
            token = bm.group(1)
            try:
                current_branches.append(float(token) > 0.0)
            except ValueError:
                current_branches.append(token not in {"0", "0.0", "0%"})
    if current_branches and current_source_line is not None:
        decisions.append((current_source_line, all(current_branches)))

    # De-duplicate source-line groups while retaining the strictest interpretation.
    grouped: dict[int, bool] = {}
    for src_line, covered in decisions:
        grouped[src_line] = grouped.get(src_line, True) and covered
    decision_total = len(grouped)
    decision_covered = sum(1 for covered in grouped.values() if covered)

    return (line_covered, line_total, function_covered, function_total,
            branch_covered, branch_total, decision_covered, decision_total)


def pct(c: int, t: int) -> float:
    return 0.0 if t == 0 else 100.0 * c / t


def main() -> int:
    if len(sys.argv) < 3:
        print("Usage: coverage_report.py <build-dir> <output-dir>", file=sys.stderr)
        return 2
    build = Path(sys.argv[1]).resolve()
    output = Path(sys.argv[2]).resolve()
    output.mkdir(parents=True, exist_ok=True)

    files = run_gcov(build)
    totals = [0] * 8
    per_file = []
    for f in files:
        values = parse_gcov(f)
        if sum(values) == 0:
            continue
        per_file.append((f.name, values))
        for i, value in enumerate(values):
            totals[i] += value

    lc, lt, fc, ft, bc, bt, dc, dt = totals
    metrics = {
        "Statements / Lines": pct(lc, lt),
        "Functions": pct(fc, ft),
        "Branches": pct(bc, bt),
        "Decisions": pct(dc, dt),
    }
    measured = lt > 0 and ft > 0 and bt > 0 and dt > 0
    overall = min(metrics.values()) if measured else 0.0
    status = "PASS" if measured and all(v >= THRESHOLD for v in metrics.values()) else "FAIL"

    lines = [
        "============================================================",
        "                 C++ CODE COVERAGE REPORT",
        "============================================================",
        "",
        "Coverage source: GCC gcov instrumented project code",
        "Coverage KPI scope: every file in src/ (whole edge_iot_core library).",
        "Excluded: main.cpp (application entry point / argv wiring only).",
        "",
        "Coverage",
        "------------------------------------------------------------",
        f"  Statements / Lines      : {lc} / {lt} = {metrics['Statements / Lines']:.2f}%",
        f"  Functions               : {fc} / {ft} = {metrics['Functions']:.2f}%",
        f"  Branches                : {bc} / {bt} = {metrics['Branches']:.2f}%",
        f"  Decisions               : {dc} / {dt} = {metrics['Decisions']:.2f}%",
        "------------------------------------------------------------",
        f"  OVERALL (minimum)      : {overall:.2f}%",
        "------------------------------------------------------------",
        f"  Required threshold     : {THRESHOLD:.2f}%",
        f"  STATUS                 : {status}",
        "",
        "Decision metric note: a source-line decision is counted covered only when all gcov-recorded branch outcomes for that decision are exercised.",
        "============================================================",
    ]
    report = "\n".join(lines) + "\n"
    print(report, end="")
    (output / "coverage_report.txt").write_text(report)

    # Simple standalone HTML report; values are generated from real gcov data.
    rows = "".join(f"<tr><td>{name}</td><td>{value:.2f}%</td></tr>" for name, value in metrics.items())
    html = f"""<!doctype html><html><head><meta charset='utf-8'><title>Edge IoT Coverage</title></head>
<body><h1>C++ Code Coverage Report</h1><p>Threshold: {THRESHOLD:.2f}%</p>
<table border='1' cellpadding='6'><tr><th>Metric</th><th>Coverage</th></tr>{rows}<tr><th>Overall (minimum)</th><th>{overall:.2f}%</th></tr></table>
<p>Status: <strong>{status}</strong></p>
<p>Decision coverage is gcov-derived: every recorded branch outcome for a decision must execute.</p></body></html>"""
    (output / "index.html").write_text(html)
    return 0 if status == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
