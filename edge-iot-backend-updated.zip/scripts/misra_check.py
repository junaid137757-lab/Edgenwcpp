#!/usr/bin/env python3
"""Lightweight, self-contained MISRA C++ compliance scanner.

HONESTY NOTE (read this before trusting the PASS banner):
This is a regex/heuristic scanner, not a certified MISRA static
analysis tool. Full MISRA C++ certification requires a licensed
analyzer (e.g. PC-lint Plus, LDRA, Parasoft C/C++test, Coverity) driven
by the official MISRA C++:2008/2023 rule text, which is copyrighted and
not something this script reproduces or replaces. What this script
DOES give you: a fast, repeatable, zero-dependency check for the
specific rule violations this project has committed to avoiding in
docs/MISRA_DEVIATIONS.md, run on every `make misra`/`make all` so a
regression is caught immediately instead of at an eventual paid audit.

Checks are split into two confidence tiers:
  HARD    — deterministic keyword/structure checks with negligible
            false-positive risk. A HARD violation fails the build.
  ADVISORY — heuristic pattern checks (e.g. spotting a C-style cast, or
            a non-explicit single-argument constructor) that can both
            over- and under-report depending on formatting. These are
            printed for human review but do NOT fail the build on
            their own.
"""
from __future__ import annotations

import re
import sys
from pathlib import Path
from dataclasses import dataclass, field

ROOT = Path(__file__).resolve().parent.parent
SRC_DIRS = [ROOT / "src", ROOT / "include"]
CPP_EXTENSIONS = {".cpp", ".h", ".hpp"}


@dataclass
class Finding:
    rule: str
    path: Path
    line_no: int
    line: str


@dataclass
class CheckResult:
    hard_findings: list = field(default_factory=list)
    advisory_findings: list = field(default_factory=list)


def iter_source_files():
    for base in SRC_DIRS:
        if not base.exists():
            continue
        for path in sorted(base.rglob("*")):
            if path.suffix in CPP_EXTENSIONS and path.is_file():
                yield path


def strip_line_comment(line: str) -> str:
    """Best-effort removal of a trailing // comment (not string-aware,
    but good enough for keyword-level checks on a formatted codebase)."""
    idx = line.find("//")
    return line if idx == -1 else line[:idx]


def read_lines(path: Path) -> list:
    try:
        return path.read_text(encoding="utf-8", errors="replace").splitlines()
    except OSError:
        return []


# ---------------------------------------------------------------------------
# HARD checks
# ---------------------------------------------------------------------------

def check_no_goto(result: CheckResult) -> None:
    pattern = re.compile(r"\bgoto\b")
    for path in iter_source_files():
        for i, raw_line in enumerate(read_lines(path), start=1):
            line = strip_line_comment(raw_line)
            if pattern.search(line):
                result.hard_findings.append(Finding("no-goto", path, i, raw_line.strip()))


def check_no_malloc_family(result: CheckResult) -> None:
    pattern = re.compile(r"\b(malloc|calloc|realloc|free)\s*\(")
    for path in iter_source_files():
        for i, raw_line in enumerate(read_lines(path), start=1):
            line = strip_line_comment(raw_line)
            if pattern.search(line):
                result.hard_findings.append(Finding("no-c-heap-functions", path, i, raw_line.strip()))


def check_no_unions(result: CheckResult) -> None:
    pattern = re.compile(r"\bunion\s+\w*\s*\{")
    for path in iter_source_files():
        for i, raw_line in enumerate(read_lines(path), start=1):
            line = strip_line_comment(raw_line)
            if pattern.search(line):
                result.hard_findings.append(Finding("no-unions", path, i, raw_line.strip()))


def check_no_using_namespace_std(result: CheckResult) -> None:
    pattern = re.compile(r"\busing\s+namespace\s+std\s*;")
    for path in iter_source_files():
        for i, raw_line in enumerate(read_lines(path), start=1):
            line = strip_line_comment(raw_line)
            if pattern.search(line):
                result.hard_findings.append(Finding("no-using-namespace-std", path, i, raw_line.strip()))


def check_no_raw_new_delete(result: CheckResult) -> None:
    # Matches ` new Foo` / ` new Foo[` / ` delete ptr` / ` delete[] ptr`
    # while excluding `new(std::nothrow)`-style placement forms is out
    # of scope for a regex — none of those appear in this codebase per
    # docs/MISRA_DEVIATIONS.md D1, so a plain keyword match is enough.
    new_pattern = re.compile(r"(?<![A-Za-z0-9_])new\s+[A-Za-z_:<]")
    delete_pattern = re.compile(r"(?<![A-Za-z0-9_])delete(\[\])?\s+[A-Za-z_]")
    for path in iter_source_files():
        for i, raw_line in enumerate(read_lines(path), start=1):
            line = strip_line_comment(raw_line)
            if new_pattern.search(line):
                result.hard_findings.append(Finding("no-raw-new", path, i, raw_line.strip()))
            if delete_pattern.search(line):
                result.hard_findings.append(Finding("no-raw-delete", path, i, raw_line.strip()))


def check_switch_has_default(result: CheckResult) -> None:
    # Structural (brace-depth) check per switch statement, not a whole-
    # file keyword tally, so one missing default among several switches
    # in the same file is still caught precisely.
    for path in iter_source_files():
        if path.suffix != ".cpp":
            continue  # switch statements live in .cpp files in this project
        text = "\n".join(strip_line_comment(l) for l in read_lines(path))
        for match in re.finditer(r"\bswitch\s*\([^)]*\)\s*\{", text):
            start = match.end() - 1  # position of the opening '{'
            depth = 0
            end = None
            for idx in range(start, len(text)):
                if text[idx] == "{":
                    depth += 1
                elif text[idx] == "}":
                    depth -= 1
                    if depth == 0:
                        end = idx
                        break
            if end is None:
                continue  # unterminated switch (shouldn't happen in valid C++)
            body = text[start:end]
            line_no = text.count("\n", 0, match.start()) + 1
            if "default:" not in body and "default :" not in body:
                result.hard_findings.append(
                    Finding("switch-must-have-default", path, line_no,
                            f"switch statement at line {line_no} has no default case"))


def check_header_guards(result: CheckResult) -> None:
    for base in [ROOT / "include"]:
        if not base.exists():
            continue
        for path in sorted(base.rglob("*.h")):
            lines = read_lines(path)
            head = "\n".join(lines[:5])
            has_pragma_once = "#pragma once" in head
            has_ifndef_define = bool(
                re.search(r"#ifndef\s+\w+", head) and re.search(r"#define\s+\w+", head))
            if not (has_pragma_once or has_ifndef_define):
                result.hard_findings.append(
                    Finding("header-must-have-include-guard", path, 1,
                            "no #pragma once or #ifndef/#define guard found in first 5 lines"))


# ---------------------------------------------------------------------------
# ADVISORY checks (heuristic — reviewed by a human, do not gate the build)
# ---------------------------------------------------------------------------

def check_possible_c_style_casts(result: CheckResult) -> None:
    cast_types = (r"int|unsigned|long|short|double|float|bool|char|size_t|"
                  r"int8_t|int16_t|int32_t|int64_t|uint8_t|uint16_t|uint32_t|uint64_t")
    pattern = re.compile(rf"\(\s*({cast_types})\s*\*?\s*\)\s*[A-Za-z_(]")
    for path in iter_source_files():
        for i, raw_line in enumerate(read_lines(path), start=1):
            line = strip_line_comment(raw_line)
            if "sizeof" in line:
                continue
            if pattern.search(line):
                result.advisory_findings.append(Finding("possible-c-style-cast", path, i, raw_line.strip()))


def check_possible_implicit_single_arg_constructors(result: CheckResult) -> None:
    # Rough heuristic for MISRA C++ Rule 12-1-3 (single-argument
    # constructors should be explicit to prevent implicit conversions).
    # High false-positive risk: multi-line signatures, default
    # arguments, and copy/move constructors will confuse this. Treat
    # findings as "worth a human look", not proof of a violation.
    pattern = re.compile(r"^\s*(?!explicit\b)([A-Za-z_]\w*)\s*\(\s*(const\s+)?[\w:<>,\s&*]+\s+\w+\s*\)\s*(:|;|\{)")
    for path in iter_source_files():
        if path.suffix != ".h":
            continue
        class_name = None
        for i, raw_line in enumerate(read_lines(path), start=1):
            line = strip_line_comment(raw_line)
            class_match = re.search(r"\bclass\s+(\w+)", line)
            if class_match:
                class_name = class_match.group(1)
            if class_name and re.match(rf"^\s*(?!explicit\b){re.escape(class_name)}\s*\(", line):
                # Skip default/copy/move constructors and anything
                # already using explicit, multiple params, or '=default'.
                if ("(" in line and "," not in line.split(")")[0]
                        and "=" not in line and "explicit" not in line
                        and f"{class_name}(const {class_name}&" not in line
                        and f"{class_name}({class_name}&&" not in line
                        and f"{class_name}()" not in line):
                    result.advisory_findings.append(
                        Finding("possible-non-explicit-single-arg-ctor", path, i, raw_line.strip()))


# ---------------------------------------------------------------------------
# Report
# ---------------------------------------------------------------------------

def main() -> int:
    result = CheckResult()

    check_no_goto(result)
    check_no_malloc_family(result)
    check_no_unions(result)
    check_no_using_namespace_std(result)
    check_no_raw_new_delete(result)
    check_switch_has_default(result)
    check_header_guards(result)

    check_possible_c_style_casts(result)
    check_possible_implicit_single_arg_constructors(result)

    files_scanned = sum(1 for _ in iter_source_files())

    print("=" * 70)
    print("           MISRA C++ COMPLIANCE SCAN (heuristic, non-certified)")
    print("=" * 70)
    print(f"Files scanned: {files_scanned} (src/ + include/, .cpp/.h)")
    print(f"Deviation record: docs/MISRA_DEVIATIONS.md")
    print("-" * 70)

    print(f"\nHARD checks (fail the build): {len(result.hard_findings)} violation(s)")
    for f in result.hard_findings:
        rel = f.path.relative_to(ROOT)
        print(f"  [{f.rule}] {rel}:{f.line_no}: {f.line}")

    print(f"\nADVISORY checks (review only): {len(result.advisory_findings)} flagged")
    for f in result.advisory_findings:
        rel = f.path.relative_to(ROOT)
        print(f"  [{f.rule}] {rel}:{f.line_no}: {f.line}")

    print("\n" + "-" * 70)
    if result.hard_findings:
        print(f"STATUS: FAIL — {len(result.hard_findings)} hard violation(s) found.")
        print("=" * 70)
        return 1

    print("STATUS: PASS — no hard violations found.")
    if result.advisory_findings:
        print(f"({len(result.advisory_findings)} advisory item(s) above are worth a human look, "
              f"but do not fail this check — heuristic false positives are expected.)")
    print("=" * 70)
    return 0


if __name__ == "__main__":
    sys.exit(main())
