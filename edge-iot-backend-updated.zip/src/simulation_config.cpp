#include "simulation_config.h"

#include <iostream>
#include <cstring>

namespace {

bool matchesFlag(const char* arg, const char* short_flag, const char* long_flag) {
    return (std::strcmp(arg, short_flag) == 0) || (std::strcmp(arg, long_flag) == 0);
}

}  // namespace

void SimulationConfig::printUsage(const std::string& program_name) {
    std::cout <<
        "Usage: " << program_name << " [options]\n"
        "\n"
        "Options:\n"
        "  -d, --devices <N>       Number of simulated IoT devices (default: 100)\n"
        "  -e, --edges <N>         Number of simulated edge nodes (default: 10)\n"
        "  -t, --tasks <N>         Number of tasks to generate (default: 10000)\n"
        "      --scheduler <name>   fifo | priority_based | edf | round_robin\n"
        "      --interactive         Ask for Auto/Manual scheduling mode at startup\n"
        "      --delay <ms>          Delay between verbose task cycles (default: 750)\n"
        "      --mqtt              Enable MQTT publishing (requires a running broker)\n"
        "      --broker <addr>     MQTT broker address (default: tcp://localhost:1883)\n"
        "      --db <path>         SQLite database path (default: data/simulation.db)\n"
        "      --verbose           Enable detailed task lifecycle trace\n"
        "  -h, --help              Show this message\n";
}

SimulationConfig SimulationConfig::parseArgs(int argc, char** argv) {
    SimulationConfig config;

    for (int i = 1; i < argc; ++i) {
        const char* arg = argv[i];
        const bool has_next = (i + 1) < argc;

        if (matchesFlag(arg, "-d", "--devices") && has_next) {
            config.device_count = static_cast<std::size_t>(std::stoul(argv[++i]));
        } else if (matchesFlag(arg, "-e", "--edges") && has_next) {
            config.edge_node_count = static_cast<std::size_t>(std::stoul(argv[++i]));
        } else if (matchesFlag(arg, "-t", "--tasks") && has_next) {
            config.task_count = static_cast<std::size_t>(std::stoul(argv[++i]));
        } else if (std::strcmp(arg, "--scheduler") == 0 && has_next) {
            config.scheduling = argv[++i];
        } else if (std::strcmp(arg, "--interactive") == 0) {
            config.interactive = true;
        } else if (std::strcmp(arg, "--delay") == 0 && has_next) {
            config.cycle_delay_ms = static_cast<unsigned int>(std::stoul(argv[++i]));
        } else if (std::strcmp(arg, "--mqtt") == 0) {
            config.use_mqtt = true;
        } else if (std::strcmp(arg, "--broker") == 0 && has_next) {
            config.mqtt_broker = argv[++i];
        } else if (std::strcmp(arg, "--db") == 0 && has_next) {
            config.db_path = argv[++i];
        } else if (std::strcmp(arg, "--verbose") == 0) {
            config.verbose = true;
        } else if (matchesFlag(arg, "-h", "--help")) {
            printUsage(argv[0]);
            std::exit(0);
        } else {
            std::cerr << "Unknown argument: " << arg << "\n";
            printUsage(argv[0]);
            std::exit(1);
        }
    }

    return config;
}
