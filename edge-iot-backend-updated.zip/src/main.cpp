#include "simulation_config.h"
#include "common/logger.h"
#include "common/constants.h"

#include "iot_device/iot_device.h"
#include "iot_device/sensor_simulator.h"
#include "task/task.h"
#include "task/task_manager.h"
#include "task/task_profile.h"
#include "edge/edge_node.h"
#include "edge/resource_monitor.h"
#include "resource/resource_allocator.h"
#include "resource/resource_controller.h"
#include "scheduler/task_scheduler.h"
#include "executor/task_executor.h"
#include "database/database_manager.h"
#include "metrics/metrics_collector.h"

#include <vector>
#include <memory>
#include <chrono>
#include <thread>
#include <random>
#include <iostream>
#include <sstream>
#include <iomanip>

namespace {

ResourceAllocator::AllocationStrategy allocationStrategy() {
    return ResourceAllocator::AllocationStrategy::MULTI_CONSTRAINT;
}

std::string allocationStrategyLabel() {
    return "Multi-Constraint Resource Allocation";
}

TaskScheduler::SchedulingStrategy schedulingFromString(const std::string& name) {
    if (name == "fifo") return TaskScheduler::SchedulingStrategy::FIFO;
    if (name == "edf") return TaskScheduler::SchedulingStrategy::EARLIEST_DEADLINE_FIRST;
    if (name == "round_robin") return TaskScheduler::SchedulingStrategy::ROUND_ROBIN_TIME_SLICE;
    return TaskScheduler::SchedulingStrategy::PRIORITY_BASED;
}

std::string priorityToLabel(Task::TaskPriority p) {
    switch (p) { case Task::TaskPriority::LOW:return "LOW"; case Task::TaskPriority::MEDIUM:return "MEDIUM"; case Task::TaskPriority::HIGH:return "HIGH"; case Task::TaskPriority::CRITICAL:return "CRITICAL"; default:return "UNKNOWN";}
}

std::string taskStatusToLabel(Task::TaskStatus status) {
    switch (status) {
        case Task::TaskStatus::CREATED: return "CREATED";
        case Task::TaskStatus::SCHEDULED: return "SCHEDULED";
        case Task::TaskStatus::ALLOCATED: return "ALLOCATED";
        case Task::TaskStatus::QUEUED: return "QUEUED";
        case Task::TaskStatus::RUNNING: return "RUNNING";
        case Task::TaskStatus::COMPLETED: return "COMPLETED";
        case Task::TaskStatus::FAILED: return "FAILED";
        case Task::TaskStatus::DEADLINE_MISSED: return "DEADLINE_MISSED";
        case Task::TaskStatus::REALLOCATED: return "REALLOCATED";
        default: return "UNKNOWN";
    }
}

struct CycleTaskRecord {
    std::shared_ptr<Task> task;
    std::string edge_id;
};

void printNodeDistribution(
    const std::vector<std::shared_ptr<EdgeNode>>& edges,
    const std::vector<CycleTaskRecord>& history) {
    std::cout << "\n============================================================\n"
              << "                    EDGE NODE STATUS\n"
              << "============================================================\n";

    for (const auto& edge : edges) {
        std::cout << "\n" << edge->getEdgeId() << "\n";
        bool found = false;
        for (const auto& record : history) {
            if (record.edge_id == edge->getEdgeId() && record.task != nullptr) {
                found = true;
                std::cout << "    " << record.task->getTaskId()
                          << " -> " << taskStatusToLabel(record.task->getStatus()) << "\n";
            }
        }
        if (!found) {
            std::cout << "    No tasks\n";
        }
    }

    bool has_unallocated = false;
    for (const auto& record : history) {
        if (record.edge_id.empty()) {
            has_unallocated = true;
            break;
        }
    }
    if (has_unallocated) {
        std::cout << "\nUNALLOCATED\n";
        for (const auto& record : history) {
            if (record.edge_id.empty() && record.task != nullptr) {
                std::cout << "    " << record.task->getTaskId()
                          << " -> " << taskStatusToLabel(record.task->getStatus()) << "\n";
            }
        }
    }
}

TaskScheduler::SchedulingStrategy chooseAutoSchedulingStrategy(
    const std::shared_ptr<Task>& task, std::size_t cycle_index) {
    if (task == nullptr) {
        return TaskScheduler::SchedulingStrategy::FIFO;
    }

    const auto requirements = task->getRequirements();

    // Auto mode adapts to workload characteristics instead of silently
    // selecting Priority Based for every cycle.
    if (requirements.priority == Task::TaskPriority::CRITICAL) {
        return TaskScheduler::SchedulingStrategy::PRIORITY_BASED;
    }
    if (requirements.deadline_ms <= 100) {
        return TaskScheduler::SchedulingStrategy::EARLIEST_DEADLINE_FIRST;
    }
    if ((cycle_index % 3U) == 0U) {
        return TaskScheduler::SchedulingStrategy::ROUND_ROBIN_TIME_SLICE;
    }
    return TaskScheduler::SchedulingStrategy::FIFO;
}

std::string schedulingToLabel(TaskScheduler::SchedulingStrategy strategy) {
    switch (strategy) {
        case TaskScheduler::SchedulingStrategy::FIFO:
            return "FIFO";
        case TaskScheduler::SchedulingStrategy::PRIORITY_BASED:
            return "Priority Based";
        case TaskScheduler::SchedulingStrategy::EARLIEST_DEADLINE_FIRST:
            return "Earliest Deadline First (EDF)";
        case TaskScheduler::SchedulingStrategy::ROUND_ROBIN_TIME_SLICE:
            return "Round Robin Time Slice";
        default:
            return "Unknown";
    }
}

/**
 * Builds the edge-node fleet described in spec §7, scaled to
 * config.edge_node_count. The first three nodes match the spec's
 * worked examples (E01/E02/E03) exactly; additional nodes get
 * randomized-but-plausible capacities.
 */
std::vector<std::shared_ptr<EdgeNode>> createEdgeNodes(
    std::size_t count, std::shared_ptr<ResourceMonitor> monitor) {

    std::vector<std::shared_ptr<EdgeNode>> nodes;
    nodes.reserve(count);

    static thread_local std::mt19937 generator(42);  // Fixed seed: reproducible experiment comparisons.
    std::uniform_real_distribution<double> ram_dist(4096.0, 32768.0);
    std::uniform_real_distribution<double> bandwidth_dist(50.0, 200.0);
    std::uniform_int_distribution<int64_t> latency_dist(8, 40);

    for (std::size_t i = 0U; i < count; ++i) {
        std::ostringstream id;
        id << "E" << std::setfill('0') << std::setw(2) << (i + 1U);

        EdgeNode::ResourceCapacity capacity;
        capacity.cpu_percent = 100.0;
        capacity.ram_mb = ram_dist(generator);
        capacity.bandwidth_mbps = bandwidth_dist(generator);
        capacity.latency_ms = latency_dist(generator);

        auto node = std::make_shared<EdgeNode>(id.str(), capacity);
        nodes.push_back(node);
        monitor->registerEdgeNode(node);

        DatabaseManager::getInstance().saveEdgeNode(node);
    }

    return nodes;
}

/**
 * Builds the IoT device fleet (spec §16: "100 simulated IoT devices"),
 * distributed across the sensor types this implementation supports.
 */
std::vector<std::shared_ptr<IoTDevice>> createDevices(std::size_t count) {
    std::vector<std::shared_ptr<IoTDevice>> devices;
    devices.reserve(count);

    static const std::vector<IoTDevice::DeviceType> kTypes = {
        IoTDevice::DeviceType::ULTRASONIC,
        IoTDevice::DeviceType::TEMPERATURE,
        IoTDevice::DeviceType::CAMERA,
        IoTDevice::DeviceType::HUMIDITY,
        IoTDevice::DeviceType::PRESSURE
    };

    for (std::size_t i = 0U; i < count; ++i) {
        const IoTDevice::DeviceType type = kTypes[i % kTypes.size()];

        std::ostringstream id;
        id << "DEV" << std::setfill('0') << std::setw(4) << (i + 1U);

        IoTDevice::DeviceConfig config;
        config.device_id = id.str();
        config.type = type;
        config.data_generation_interval_ms = 200.0;
        config.data_variance = 0.05;

        std::shared_ptr<IoTDevice> device;
        switch (type) {
            case IoTDevice::DeviceType::ULTRASONIC:
                device = std::make_shared<UltrasonicSensor>(config);
                break;
            case IoTDevice::DeviceType::TEMPERATURE:
                device = std::make_shared<TemperatureSensor>(config);
                break;
            case IoTDevice::DeviceType::CAMERA:
                device = std::make_shared<CameraSensor>(config);
                break;
            case IoTDevice::DeviceType::HUMIDITY:
                device = std::make_shared<HumiditySensor>(config);
                break;
            case IoTDevice::DeviceType::PRESSURE:
                device = std::make_shared<PressureSensor>(config);
                break;
            default:
                device = std::make_shared<UltrasonicSensor>(config);
                break;
        }

        devices.push_back(device);
        DatabaseManager::getInstance().saveDevice(config.device_id, device->getTypeString());
    }

    return devices;
}

/**
 * Runs one full experiment: generates `task_count` tasks from the
 * device fleet using the given allocation strategy, allocates them,
 * executes them, and returns a metrics snapshot. This is the unit of
 * work spec §18 calls "Experiment N".
 */
MetricsCollector::Snapshot runExperiment(
    const SimulationConfig& config,
    TaskScheduler::SchedulingStrategy scheduling_strategy,
    const std::vector<std::shared_ptr<IoTDevice>>& devices,
    bool adaptive_auto_mode) {

    Logger& logger = Logger::getInstance();
    logger.info("Simulation", "=== Running experiment: Multi-Constraint Resource Allocation ===");

    auto monitor = std::make_shared<ResourceMonitor>();
    const std::vector<std::shared_ptr<EdgeNode>> edges = createEdgeNodes(config.edge_node_count, monitor);

    auto task_manager = std::make_shared<TaskManager>();
    auto allocator = std::make_shared<ResourceAllocator>(monitor, allocationStrategy());
    auto scheduler = std::make_shared<TaskScheduler>(scheduling_strategy);
    auto executor = std::make_shared<TaskExecutor>(scheduler);

    for (const auto& edge : edges) {
        executor->registerEdgeNode(edge);
    }

    // Start workers before producing tasks. This provides real execution
    // concurrency, so resources are released as tasks complete instead of
    // accumulating reservations for all 10,000 generated tasks.
    executor->start();

    const auto start_time = std::chrono::steady_clock::now();

    std::vector<CycleTaskRecord> task_history;
    task_history.reserve(config.task_count);

    // Generate and allocate tasks. Devices cycle round-robin to reach
    // config.task_count total tasks regardless of device_count.
    for (std::size_t i = 0U; i < config.task_count; ++i) {
        const std::shared_ptr<IoTDevice>& device = devices[i % devices.size()];
        const json sensor_data = device->generateSensorData();

        std::shared_ptr<Task> task = task_manager->createTaskFromSensorData(
            device->getDeviceId(), device->getTypeString(), sensor_data);

        logger.debug("TaskGeneration",
            "Generated " + task->getTaskId() + " from device " + device->getDeviceId() +
            " (sensor=" + device->getTypeString() + ")");

        if (adaptive_auto_mode) {
            scheduling_strategy = chooseAutoSchedulingStrategy(task, i + 1U);
            scheduler->setStrategy(scheduling_strategy);
        }

        if (config.verbose) {
            const auto req = task->getRequirements();
            std::cout << "\n============================================================\n"
                      << "                    TASK CYCLE #" << (i + 1U) << "\n"
                      << "============================================================\n\n"
                      << "[SENSOR DATA]\n"
                      << "  Device       : " << device->getDeviceId()
                      << "\n  Sensor       : " << device->getTypeString()
                      << "\n  Value        : " << sensor_data.dump() << "\n\n"
                      << "[TASK GENERATED]\n"
                      << "  Task ID      : " << task->getTaskId()
                      << "\n  CPU          : " << req.cpu_percent << "%"
                      << "\n  Memory       : " << req.ram_mb << " MB"
                      << "\n  Bandwidth    : " << req.bandwidth_mbps << " Mbps"
                      << "\n  Priority     : " << priorityToLabel(req.priority)
                      << "\n  Deadline     : " << req.deadline_ms << " ms"
                      << "\n  Execution    : estimated by executor"
                      << "\n  Task Message : " << task->toJson().dump() << "\n\n"
                      << "[SCHEDULER]\n"
                      << "  Algorithm    : " << schedulingToLabel(scheduling_strategy) << "\n\n"
                      << "[ALLOCATOR]\n"
                      << "  Algorithm    : " << allocationStrategyLabel() << "\n";
        }

        DatabaseManager::getInstance().saveTask(task);

        // Apply bounded back-pressure. A busy system is not treated as a
        // permanent allocation failure; the request waits for a node to
        // release resources after executing an earlier task.
        const ResourceAllocator::AllocationResult result =
            allocator->allocateTaskWithRetry(task, 200U, std::chrono::milliseconds(5));

        if (result.success) {
            scheduler->scheduleTask(monitor->getEdgeNode(result.edge_id), task);
            DatabaseManager::getInstance().saveAllocation(
                task->getTaskId(), result.edge_id, result.score);
            task_history.push_back(CycleTaskRecord{task, result.edge_id});
            if (config.verbose) {
                std::cout << "  Candidate Edges:\n";
                for (const auto& candidate : result.candidates) {
                    std::cout << "    " << candidate.edge_id
                              << " -> Score: " << std::fixed << std::setprecision(2) << candidate.score
                              << " -> " << (candidate.feasible ? "FEASIBLE" : "INFEASIBLE") << "\n";
                }
                std::cout << "  Selected Edge : " << result.edge_id
                          << "\n  Score         : " << std::fixed << std::setprecision(2) << result.score
                          << "\n  Decision      : " << result.reason << "\n";

                // Wait for the worker to actually start before reporting
                // execution, eliminating the misleading QUEUED/QUEUED result.
                executor->waitForRunning(task, std::chrono::milliseconds(250));
                std::cout << "\n[EXECUTION]\n"
                          << "  Task         : " << task->getTaskId()
                          << "\n  Edge         : " << result.edge_id
                          << "\n  Status       : " << taskStatusToLabel(task->getStatus()) << "\n";

                // Wait for the terminal result so the result section reflects
                // the actual execution outcome rather than a race with the worker.
                executor->waitForCompletion(task, std::chrono::milliseconds(500));
            }
        } else {
            task_history.push_back(CycleTaskRecord{task, ""});
            DatabaseManager::getInstance().saveAllocationFailure(
                task->getTaskId(), result.reason);
            if (config.verbose) {
                std::cout << "  Candidate Edges: none\n"
                          << "  Selected Edge : NONE\n"
                          << "  Reason        : " << result.reason << "\n\n"
                          << "[EXECUTION]\n  Status       : FAILED\n";
            }
        }

        // Periodic background resource fluctuation, matching spec §7/§9
        // ("the simulator continuously changes their resource usage").
        if ((i % 100U) == 0U) {
            monitor->updateResourceMetrics();
        }
        if (config.verbose) {
            std::cout << "\n[EXECUTION RESULT]\n"
                      << "  Task         : " << task->getTaskId()
                      << "\n  Edge         : " << (result.success ? result.edge_id : "NONE")
                      << "\n  Status       : " << taskStatusToLabel(task->getStatus()) << "\n";
            printNodeDistribution(edges, task_history);
            std::cout << "\n============================================================\n"
                      << "                  CYCLE #" << (i + 1U) << " COMPLETED\n"
                      << "============================================================\n";
            std::this_thread::sleep_for(std::chrono::milliseconds(config.cycle_delay_ms));
        }
    }

    // Let the executor drain the queues. In a real interactive run this
    // would be event-driven; here we poll until queues empty or a
    // generous timeout elapses, to keep experiment runs bounded.
    constexpr int kMaxDrainSeconds = 30;
    const auto drain_deadline = std::chrono::steady_clock::now() + std::chrono::seconds(kMaxDrainSeconds);

    bool any_queued = true;
    while (any_queued && std::chrono::steady_clock::now() < drain_deadline) {
        any_queued = false;
        for (const auto& edge : edges) {
            if (edge->hasTasksInQueue()) {
                any_queued = true;
                break;
            }
        }
        std::this_thread::sleep_for(std::chrono::milliseconds(50));
    }

    executor->stop();

    const auto end_time = std::chrono::steady_clock::now();
    const double elapsed_seconds =
        std::chrono::duration<double>(end_time - start_time).count();

    MetricsCollector collector(allocator, executor, monitor);
    const MetricsCollector::Snapshot snapshot = collector.collect(elapsed_seconds);

    logger.info("Simulation",
        "Experiment complete: " + std::to_string(allocator->getTotalAllocations()) +
        " tasks processed, " + std::to_string(allocator->getSuccessRate()) + "% allocated successfully.");

    return snapshot;
}

}  // namespace

int main(int argc, char** argv) {
    SimulationConfig config = SimulationConfig::parseArgs(argc, argv);
    bool adaptive_auto_mode = false;

    if (config.interactive) {
        std::cout << "\n=== EDGE IOT SIMULATION MODE ===\n"
                  << "1. Auto (adaptive)\n"
                  << "2. Manual selection\n"
                  << "Choose mode: ";
        int mode = 1;
        std::cin >> mode;
        adaptive_auto_mode = (mode != 2);
        if (mode == 2) {
            std::cout << "\nScheduling Algorithm\n"
                      << "1. Priority Based\n"
                      << "2. EDF (Earliest Deadline First)\n"
                      << "3. Round Robin\n"
                      << "4. FIFO\n"
                      << "Choose scheduler: ";
            int sch = 1;
            std::cin >> sch;
            switch (sch) {
                case 2: config.scheduling = "edf"; break;
                case 3: config.scheduling = "round_robin"; break;
                case 4: config.scheduling = "fifo"; break;
                default: config.scheduling = "priority_based"; break;
            }
        }
        std::cout << "\nAllocation Strategy\n"
                  << "Multi-Constraint Resource Allocation (default and only allocator)\n";
    }

    Logger& logger = Logger::getInstance();
    logger.setLogFile(config.log_path);
    if (config.verbose) {
        logger.setMinLevel(Logger::Level::DEBUG);
    }
    logger.info("Simulation", "Edge IoT Simulator starting.");
    logger.info("Simulation",
        "Config: devices=" + std::to_string(config.device_count) +
        " edges=" + std::to_string(config.edge_node_count) +
        " tasks=" + std::to_string(config.task_count));
    logger.info("Simulation",
        "Allocation strategy: Multi-Constraint Resource Allocation");
    logger.info("Simulation",
        "Scheduling algorithm: " + schedulingToLabel(schedulingFromString(config.scheduling)));
    if (config.verbose) {
        logger.info("Simulation", "Verbose trace: ENABLED");
    }

    if (!DatabaseManager::getInstance().initialize(config.db_path)) {
        logger.error("Simulation", "Failed to initialize database at " + config.db_path);
        return 1;
    }

    if (!DatabaseManager::getInstance().resetSimulationData()) {
        logger.error("Simulation", "Failed to reset previous simulation data");
        DatabaseManager::getInstance().close();
        return 1;
    }

    TaskProfile::getInstance().loadProfiles(config.db_path);
    for (const auto& profile_entry : TaskProfile::getInstance().getAllProfiles()) {
        DatabaseManager::getInstance().saveTaskProfile(profile_entry.first, profile_entry.second);
    }

    const std::vector<std::shared_ptr<IoTDevice>> devices = createDevices(config.device_count);

    const MetricsCollector::Snapshot snapshot = runExperiment(
        config,
        schedulingFromString(config.scheduling),
        devices,
        adaptive_auto_mode);

    std::cout << "\n=== Simulation Results (Multi-Constraint Resource Allocation) ===\n";
    std::cout << "Average waiting time:      " << snapshot.average_waiting_time_ms << " ms\n";
    std::cout << "Average latency:           " << snapshot.average_latency_ms << " ms\n";
    std::cout << "Deadline miss rate:        " << snapshot.deadline_miss_rate_percent << " %\n";
    std::cout << "Average CPU utilization:   " << snapshot.average_cpu_utilization_percent << " %\n";
    std::cout << "Load imbalance (stddev):   " << snapshot.load_imbalance_stddev << "\n";
    std::cout << "Throughput:                " << snapshot.throughput_tasks_per_second << " tasks/sec\n";
    std::cout << "Task success rate:         " << snapshot.task_success_rate_percent << " %\n";

    DatabaseManager::getInstance().close();
    logger.info("Simulation", "Edge IoT Simulator finished.");
    return 0;
}
