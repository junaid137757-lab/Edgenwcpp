#include "resource/resource_allocator.h"
#include "common/constants.h"
#include "common/logger.h"

#include <algorithm>
#include <limits>
#include <thread>

namespace {

const char* allocationStrategyName() {
    return "MULTI_CONSTRAINT";
}

}  // namespace

ResourceAllocator::ResourceAllocator(
    std::shared_ptr<ResourceMonitor> monitor,
    AllocationStrategy strategy)
    : monitor_(std::move(monitor)),
      strategy_(AllocationStrategy::MULTI_CONSTRAINT),
      total_allocations_(0U),
      successful_allocations_(0U),
      failed_allocations_(0U) {
    (void)strategy;
}

std::vector<std::shared_ptr<EdgeNode>> ResourceAllocator::getViableEdges(std::shared_ptr<Task> task) {
    std::vector<std::shared_ptr<EdgeNode>> viable;
    if (task == nullptr || monitor_ == nullptr) {
        return viable;
    }

    const Task::TaskRequirements requirements = task->getRequirements();

    for (const auto& entry : monitor_->getAllEdgeNodes()) {
        const std::shared_ptr<EdgeNode>& edge = entry.second;
        if (edge == nullptr || !edge->isAvailable()) {
            continue;
        }

        if (edge->canAllocate(requirements.cpu_percent, requirements.ram_mb, requirements.bandwidth_mbps)) {
            viable.push_back(edge);
        }
    }

    return viable;
}

ResourceAllocator::AllocationResult ResourceAllocator::allocateTask(std::shared_ptr<Task> task) {
    ++total_allocations_;

    AllocationResult result = allocateMultiConstraint(task);

    if (result.success) {
        ++successful_allocations_;
        task->setAssignedEdgeId(result.edge_id);
        task->setStatus(Task::TaskStatus::ALLOCATED);
    } else {
        ++failed_allocations_;
        if (task != nullptr) {
            task->setStatus(Task::TaskStatus::FAILED);
        }
        Logger::getInstance().warn("ResourceAllocator",
            "Failed to allocate task " + (task != nullptr ? task->getTaskId() : std::string("<null>")) +
            ": " + result.reason);
    }

    return result;
}

ResourceAllocator::AllocationResult ResourceAllocator::allocateTaskWithRetry(
    std::shared_ptr<Task> task,
    std::size_t max_retries,
    std::chrono::milliseconds retry_delay) {

    AllocationResult result;
    result.success = false;
    result.score = 0.0;

    ++total_allocations_;

    for (std::size_t attempt = 0U; attempt <= max_retries; ++attempt) {
        result = allocateMultiConstraint(task);

        if (result.success) {
            ++successful_allocations_;
            task->setAssignedEdgeId(result.edge_id);
            task->setStatus(Task::TaskStatus::ALLOCATED);
            Logger::getInstance().debug(
                "ResourceAllocator",
                "Task " + task->getTaskId() +
                " allocated to " + result.edge_id +
                " using " + allocationStrategyName() +
                " (score=" + std::to_string(result.score) +
                ", reason=" + result.reason + ")");
            return result;
        }

        if (monitor_ == nullptr || monitor_->getAllEdgeNodes().empty()) {
            break;
        }

        if (attempt < max_retries) {
            std::this_thread::sleep_for(retry_delay);
        }
    }

    ++failed_allocations_;
    if (task != nullptr) {
        task->setStatus(Task::TaskStatus::FAILED);
    }
    Logger::getInstance().warn("ResourceAllocator",
        "Failed to allocate task " + (task != nullptr ? task->getTaskId() : std::string("<null>")) +
        ": " + result.reason);
    return result;
}

// ============================================================
// Multi-Constraint Score-Based Resource Allocation
// ============================================================
ResourceAllocator::AllocationResult ResourceAllocator::allocateMultiConstraint(std::shared_ptr<Task> task) {
    AllocationResult result;
    result.success = false;
    result.score = 0.0;

    if (task == nullptr || monitor_ == nullptr) {
        result.reason = "Invalid task or resource monitor";
        return result;
    }

    // Evaluate every available edge, not only feasible nodes, so the console
    // can explain both capacity rejection and the final selection.
    for (const auto& entry : monitor_->getAllEdgeNodes()) {
        const auto& edge = entry.second;
        if (edge == nullptr || !edge->isAvailable()) {
            continue;
        }

        const auto requirements = task->getRequirements();
        const bool feasible = edge->canAllocate(
            requirements.cpu_percent, requirements.ram_mb, requirements.bandwidth_mbps);

        const double score = feasible ? calculateAllocationScore(edge, task) : 0.0;
        result.candidates.push_back(CandidateScore{edge->getEdgeId(), score, feasible});

        if (feasible && score > result.score) {
            result.score = score;
            result.edge_id = edge->getEdgeId();
            result.success = true;
        }
    }

    if (!result.success) {
        result.reason = "No available edge node satisfies CPU, memory and bandwidth constraints";
        return result;
    }

    const auto selected = monitor_->getEdgeNode(result.edge_id);
    const auto requirements = task->getRequirements();
    selected->allocateResources(
        requirements.cpu_percent, requirements.ram_mb, requirements.bandwidth_mbps);

    ++allocation_history_[result.edge_id];

    result.reason =
        "Highest multi-constraint suitability score using CPU, memory, bandwidth, "
        "latency, queue load and recent allocation history";
    return result;
}

double ResourceAllocator::calculateAllocationScore(
    const std::shared_ptr<EdgeNode>& edge,
    const std::shared_ptr<Task>& task) {

    const double cpu_score = normalizeCpuScore(edge);
    const double ram_score = normalizeRamScore(edge);
    const double bandwidth_score = normalizeBandwidthScore(edge);
    const double latency_score = normalizeLatencyScore(edge);
    const double queue_score = (0.40 * normalizeQueueScore(edge)) +
        (0.60 * normalizeRecentAllocationScore(edge));
    const double pri_score = priorityScore(task->getRequirements().priority);

    const double total_score =
        (weights_.cpu_weight * cpu_score) +
        (weights_.ram_weight * ram_score) +
        (weights_.bandwidth_weight * bandwidth_score) +
        (weights_.latency_weight * latency_score) +
        (weights_.queue_weight * queue_score) +
        (weights_.priority_weight * pri_score);

    return total_score * 100.0;
}

double ResourceAllocator::normalizeCpuScore(const std::shared_ptr<EdgeNode>& edge) {
    const double capacity = edge->getCapacity().cpu_percent;
    if (capacity <= 0.0) {
        return 0.0;
    }
    return std::clamp(edge->getAvailableCpuPercent() / capacity, 0.0, 1.0);
}

double ResourceAllocator::normalizeRamScore(const std::shared_ptr<EdgeNode>& edge) {
    const double capacity = edge->getCapacity().ram_mb;
    if (capacity <= 0.0) {
        return 0.0;
    }
    return std::clamp(edge->getAvailableRamMb() / capacity, 0.0, 1.0);
}

double ResourceAllocator::normalizeBandwidthScore(const std::shared_ptr<EdgeNode>& edge) {
    const double capacity = edge->getCapacity().bandwidth_mbps;
    if (capacity <= 0.0) {
        return 0.0;
    }
    return std::clamp(edge->getAvailableBandwidthMbps() / capacity, 0.0, 1.0);
}

double ResourceAllocator::normalizeLatencyScore(const std::shared_ptr<EdgeNode>& edge) {
    constexpr double kLatencyCeilingMs = 100.0;
    const double latency = static_cast<double>(edge->getLatencyMs());
    return std::clamp(1.0 - (latency / kLatencyCeilingMs), 0.01, 1.0);
}

double ResourceAllocator::normalizeQueueScore(const std::shared_ptr<EdgeNode>& edge) {
    const double queue_length = static_cast<double>(edge->getQueueLength());
    const double ceiling = static_cast<double>(constants::kMaxQueueLengthForScore);
    return std::clamp(1.0 - (queue_length / ceiling), 0.0, 1.0);
}

double ResourceAllocator::normalizeRecentAllocationScore(const std::shared_ptr<EdgeNode>& edge) const {
    if (edge == nullptr) {
        return 0.0;
    }
    const auto it = allocation_history_.find(edge->getEdgeId());
    const uint64_t count = (it == allocation_history_.end()) ? 0U : it->second;
    // Diminishing penalty: recently selected nodes become less attractive,
    // while never making a feasible node permanently unavailable.
    return 1.0 / (1.0 + static_cast<double>(count));
}

double ResourceAllocator::priorityScore(Task::TaskPriority priority) {
    switch (priority) {
        case Task::TaskPriority::CRITICAL: return 1.0;
        case Task::TaskPriority::HIGH: return 0.75;
        case Task::TaskPriority::MEDIUM: return 0.5;
        case Task::TaskPriority::LOW: return 0.25;
        default: return 0.0;
    }
}

double ResourceAllocator::getSuccessRate() const {
    if (total_allocations_ == 0U) {
        return 0.0;
    }
    return (static_cast<double>(successful_allocations_) / static_cast<double>(total_allocations_)) * 100.0;
}
