# Adaptive Multi-Constraint Resource Allocation and Load Balancing for Edge-Based IoT Networks

A C++17 simulation of an IoT edge-computing network: simulated sensor
devices generate data, a task manager converts that data into
computational tasks, and a resource allocator distributes those tasks
across simulated edge nodes using the single Multi-Constraint Resource
Allocation strategy, which scores feasible nodes across CPU, memory,
bandwidth, latency, queue load and task priority. See the original project specification in
`docs/PROJECT_SPEC.md` for the full design rationale — this
implementation follows it section-by-section, referenced throughout the
source comments as `spec §N`.

## Quick start

```bash
cmake -B build && cmake --build build -j$(nproc)
./build/iot_simulator --devices 100 --edges 10 --tasks 10000
```

See **[docs/BUILD.md](docs/BUILD.md)** for full dependency and build
instructions, and **[docs/MISRA_DEVIATIONS.md](docs/MISRA_DEVIATIONS.md)**
for the project's documented C++ coding-standard deviations.

## Architecture

```
IoT Devices (5 sensor types)
        │  generateSensorData()
        ▼
   TaskManager  ──creates──▶  Task (with TaskRequirements from TaskProfile)
        │
        ▼
ResourceController ──uses──▶ ResourceAllocator (Multi-Constraint only)
        │                           │
        │                    scores against
        ▼                           ▼
ResourceMonitor ──tracks──▶  EdgeNode(s) (CPU/RAM/BW/latency/queue)
        │
   (on failure)
        ▼
  Reallocation ──▶ TaskScheduler (FIFO / Priority / EDF / Round Robin) ──▶ TaskExecutor
                                                          │
                                                          ▼
                                                  DatabaseManager (SQLite)
                                                          │
                                                          ▼
                                                  MetricsCollector
```

## Module map

| Module | Header | Responsibility |
|---|---|---|
| IoT Device | `include/iot_device/` | Simulated sensors (ultrasonic, temperature, camera, humidity, pressure) |
| MQTT | `include/mqtt/` | Thin transport wrapper (Paho C++); optional at build time |
| Task | `include/task/` | `Task`, `TaskProfile` (config), `TaskManager` (creation/queueing) |
| Edge | `include/edge/` | `EdgeNode` (resource accounting), `ResourceMonitor` (health/failure) |
| Resource | `include/resource/` | `ResourceAllocator` (Multi-Constraint only), `ResourceController` (orchestration) |
| Scheduler | `include/scheduler/` | `TaskScheduler` (FIFO / Priority / EDF / Round-robin-slice) |
| Database | `include/database/` | `DatabaseManager` (SQLite persistence, 7 tables per spec §12) |
| Executor | `include/executor/` | `TaskExecutor` (simulated execution, deadline checking) |
| Metrics | `include/metrics/` | `MetricsCollector` (the 7 metrics from spec §17) |
| Common | `include/common/` | `Logger`, named constants (no magic numbers project-wide) |


### Allocation back-pressure

The simulator starts edge workers before task generation. Resource reservations are
released when a task finishes, and transient resource exhaustion is handled with
bounded back-pressure rather than immediately marking the task as permanently
failed. A task is enqueued exactly once by the scheduler after allocation.

## Testing

```bash
cd build && ctest --output-on-failure
```

40 unit tests across 6 test files cover the Multi-Constraint allocator,
edge-node resource accounting, task scheduling orderings, and metrics
aggregation. See `tests/`.

## Code quality tooling

- **Compiler warnings**: `-Wall -Wextra -Wpedantic -Wshadow -Wconversion`
  and more, always on; `-DWARNINGS_AS_ERRORS=ON` promotes them to errors.
- **Sanitizers**: `-DENABLE_ASAN=ON` or `-DENABLE_TSAN=ON` for fast
  local memory/thread-safety checking.
- **Code coverage**: `-DENABLE_COVERAGE=ON` + `make coverage` generates
  an HTML report scoped to `src/`/`include/` (see `docs/BUILD.md`).
- **Valgrind**: `cmake --build build --target valgrind_memcheck` (see
  `docs/BUILD.md`).
- **MISRA C++ deviations**: fully documented in
  `docs/MISRA_DEVIATIONS.md` — read this before running any MISRA
  static-analysis tool against the codebase.

## License

No license specified — treat as all-rights-reserved unless your
instructor/institution specifies otherwise for coursework submission.

## Deterministic / no-AI package
This package intentionally contains no AI/ML allocator. Resource allocation is always Multi-Constraint Resource Allocation, and scheduling remains independently selectable (Priority, EDF, Round Robin, or FIFO). In interactive Auto mode, the scheduler adapts to the current task workload; Manual mode keeps the user's selected scheduler for the experiment.

## Coverage gate
Run `make coverage`. The command executes the test suite, collects real GCC `gcov` data, prints line/function/branch/decision percentages, writes `coverage/coverage_report.txt` and `coverage/index.html`, and returns a non-zero status if any required metric is below 95%.
