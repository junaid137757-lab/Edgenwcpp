# third_party/json/

This directory is a placeholder for a vendored copy of the
[nlohmann/json](https://github.com/nlohmann/json) single-header library,
used as a fallback when `find_package(nlohmann_json)` doesn't find a
system-installed copy (see the top-level `CMakeLists.txt`).

## Why it's not included pre-populated

The build machine that generated this project archive had no network
access, so the header could not be downloaded automatically. You have
two options:

### Option A (recommended): install the system package

```bash
# Debian/Ubuntu
sudo apt-get install nlohmann-json3-dev

# macOS
brew install nlohmann-json

# Fedora
sudo dnf install json-devel
```

With this installed, `find_package(nlohmann_json 3.9 QUIET)` in the
top-level `CMakeLists.txt` will find it automatically and this
directory is never used.

### Option B: vendor the header yourself

```bash
mkdir -p third_party/json/include/nlohmann
curl -L https://github.com/nlohmann/json/releases/download/v3.11.3/json.hpp \
     -o third_party/json/include/nlohmann/json.hpp
```

Once `third_party/json/include/nlohmann/json.hpp` exists, the CMake
fallback path (`nlohmann_json_vendored` interface target) will pick it
up automatically — no CMakeLists.txt changes needed.

## Verifying which path was used

After running `cmake -B build`, check the configure output:

```
-- nlohmann_json not found via find_package; using vendored header in third_party/json/
```

If you see that line and did NOT complete Option B, the build will fail
at the first `#include <nlohmann/json.hpp>` — install one of the two
options above first.
