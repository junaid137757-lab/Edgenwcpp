# Runtime fixes

This revision addresses the interactive simulator issues observed during task-cycle runs.

- Auto mode is adaptive instead of always using Priority Based:
  - CRITICAL tasks -> Priority Based
  - <=100 ms deadline tasks -> EDF
  - every third non-urgent cycle -> Round Robin
  - remaining tasks -> FIFO
- Allocation remains Multi-Constraint only. No allocator selection menu or baseline allocator is exposed.
- Multi-Constraint scoring now considers current resource fit, queue load, and recent allocation history so an otherwise identical node is not selected forever.
- Candidate output includes all available nodes and marks infeasible nodes.
- Execution output waits for the worker to start before showing `[EXECUTION]` and waits for a terminal state before `[EXECUTION RESULT]`, preventing `QUEUED -> QUEUED` race output.
- Edge-node status output uses the complete cycle history so completed tasks remain visible.
- Task execution now records execution-start time and reports actual average waiting time separately from average execution time.
- Execution-time jitter/model was tightened so normal camera tasks are not systematically longer than their 50 ms deadline; deadline misses remain possible when genuine waiting/overload causes them.
- Executor aggregate counters are atomic for multi-edge worker threads.
