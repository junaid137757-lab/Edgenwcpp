# ---------------------------------------------------------------------------
# Valgrind integration
#
# Provides two custom targets:
#   make valgrind_memcheck   - runs the simulator under Valgrind's memcheck
#                               tool with a small workload, using the
#                               project suppression file.
#   make valgrind_helgrind   - runs under Helgrind to check for data races
#                               / lock-order-inversion across the
#                               multithreaded ResourceController,
#                               TaskExecutor, and ResourceMonitor.
#
# Neither target runs automatically as part of `make` or `ctest` — both
# are opt-in, since Valgrind runs are slow (10-50x native speed). Run
# them explicitly, or wire valgrind_memcheck into a CI job.
#
# Usage:
#   cmake -B build && cmake --build build
#   cmake --build build --target valgrind_memcheck
# ---------------------------------------------------------------------------

find_program(VALGRIND_EXECUTABLE valgrind)

if(VALGRIND_EXECUTABLE)
    message(STATUS "Found Valgrind: ${VALGRIND_EXECUTABLE}")

    set(VALGRIND_SUPPRESSIONS_FILE ${CMAKE_SOURCE_DIR}/cmake/valgrind.supp)

    # A small, fast workload for the sanity-check target: enough to
    # exercise every module (device generation, allocation, scheduling,
    # execution, DB writes) without a multi-minute Valgrind run.
    add_custom_target(valgrind_memcheck
        COMMAND ${CMAKE_COMMAND} -E make_directory ${CMAKE_BINARY_DIR}/valgrind_data
        COMMAND ${VALGRIND_EXECUTABLE}
                --tool=memcheck
                --leak-check=full
                --show-leak-kinds=definite,indirect,possible
                --track-origins=yes
                --error-exitcode=1
                --suppressions=${VALGRIND_SUPPRESSIONS_FILE}
                --log-file=${CMAKE_BINARY_DIR}/valgrind_memcheck_report.txt
                $<TARGET_FILE:iot_simulator>
                --devices 10 --edges 3 --tasks 100
                --db ${CMAKE_BINARY_DIR}/valgrind_data/sim.db
        COMMENT "Running Valgrind memcheck (report: ${CMAKE_BINARY_DIR}/valgrind_memcheck_report.txt)"
        DEPENDS iot_simulator
        VERBATIM
    )

    add_custom_target(valgrind_helgrind
        COMMAND ${CMAKE_COMMAND} -E make_directory ${CMAKE_BINARY_DIR}/valgrind_data
        COMMAND ${VALGRIND_EXECUTABLE}
                --tool=helgrind
                --suppressions=${VALGRIND_SUPPRESSIONS_FILE}
                --log-file=${CMAKE_BINARY_DIR}/valgrind_helgrind_report.txt
                $<TARGET_FILE:iot_simulator>
                --devices 10 --edges 3 --tasks 100
                --db ${CMAKE_BINARY_DIR}/valgrind_data/sim_helgrind.db
        COMMENT "Running Valgrind helgrind (report: ${CMAKE_BINARY_DIR}/valgrind_helgrind_report.txt)"
        DEPENDS iot_simulator
        VERBATIM
    )
else()
    message(STATUS "Valgrind not found — valgrind_memcheck/valgrind_helgrind targets will be unavailable. "
                    "Install with: sudo apt-get install valgrind")
endif()
