# Coverage report generation using GCC gcov plus the project's threshold gate.
# The report is real measured coverage; the target fails if any required metric
# is below 95%.
find_package(Python3 COMPONENTS Interpreter REQUIRED)

set(COVERAGE_OUTPUT_DIR ${CMAKE_BINARY_DIR}/coverage_report)

add_custom_target(coverage
    COMMAND ${CMAKE_CTEST_COMMAND} --output-on-failure
    COMMAND ${CMAKE_COMMAND} -E make_directory ${COVERAGE_OUTPUT_DIR}
    COMMAND ${Python3_EXECUTABLE}
            ${CMAKE_SOURCE_DIR}/scripts/coverage_report.py
            ${CMAKE_BINARY_DIR}
            ${COVERAGE_OUTPUT_DIR}
    WORKING_DIRECTORY ${CMAKE_BINARY_DIR}
    DEPENDS edge_iot_tests
    COMMENT "Running tests and generating the 95% coverage gate/report"
    VERBATIM
)
