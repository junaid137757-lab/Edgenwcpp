#include <gtest/gtest.h>
#include "edge/resource_monitor.h"

#include <vector>
#include <utility>
#include <map>
#include <string>

namespace {

std::shared_ptr<EdgeNode> makeEdge(const std::string& id) {
    EdgeNode::ResourceCapacity cap;
    cap.cpu_percent = 100.0;
    cap.ram_mb = 8192.0;
    cap.bandwidth_mbps = 50.0;
    cap.latency_ms = 20;
    return std::make_shared<EdgeNode>(id, cap);
}

}  // namespace

class ResourceMonitorTest : public ::testing::Test {
protected:
    ResourceMonitor monitor;
};

TEST_F(ResourceMonitorTest, StartsWithNoRegisteredNodes) {
    EXPECT_EQ(monitor.getAllEdgeNodes().size(), 0U);
    EXPECT_EQ(monitor.getAvailableNodeCount(), 0U);
    EXPECT_EQ(monitor.getTotalNodeFailures(), 0U);
    EXPECT_EQ(monitor.getTotalNodeRecoveries(), 0U);
}

TEST_F(ResourceMonitorTest, RegisterAndRetrieveEdgeNode) {
    monitor.registerEdgeNode(makeEdge("E01"));
    const auto node = monitor.getEdgeNode("E01");
    ASSERT_NE(node, nullptr);
    EXPECT_EQ(node->getEdgeId(), "E01");
}

TEST_F(ResourceMonitorTest, GetUnknownEdgeNodeReturnsNullptr) {
    EXPECT_EQ(monitor.getEdgeNode("NOPE"), nullptr);
}

TEST_F(ResourceMonitorTest, UnregisterRemovesNode) {
    monitor.registerEdgeNode(makeEdge("E01"));
    monitor.unregisterEdgeNode("E01");
    EXPECT_EQ(monitor.getEdgeNode("E01"), nullptr);
}

TEST_F(ResourceMonitorTest, AllRegisteredNodesStartAvailable) {
    monitor.registerEdgeNode(makeEdge("E01"));
    monitor.registerEdgeNode(makeEdge("E02"));
    EXPECT_EQ(monitor.getAvailableNodeCount(), 2U);
    const auto ids = monitor.getAvailableNodeIds();
    EXPECT_EQ(ids.size(), 2U);
    EXPECT_TRUE(monitor.getFailedNodeIds().empty());
}

TEST_F(ResourceMonitorTest, SimulateNodeFailureMarksNodeUnavailable) {
    monitor.registerEdgeNode(makeEdge("E01"));
    monitor.simulateNodeFailure("E01");

    EXPECT_FALSE(monitor.getEdgeNode("E01")->isAvailable());
    EXPECT_EQ(monitor.getTotalNodeFailures(), 1U);
    EXPECT_EQ(monitor.getAvailableNodeCount(), 0U);
    const auto failed = monitor.getFailedNodeIds();
    ASSERT_EQ(failed.size(), 1U);
    EXPECT_EQ(failed[0], "E01");
}

TEST_F(ResourceMonitorTest, SimulateNodeFailureOnUnknownNodeIsNoOp) {
    EXPECT_NO_THROW(monitor.simulateNodeFailure("GHOST"));
    EXPECT_EQ(monitor.getTotalNodeFailures(), 0U);
}

TEST_F(ResourceMonitorTest, RecoverNodeFromFailureMarksNodeAvailableAgain) {
    monitor.registerEdgeNode(makeEdge("E01"));
    monitor.simulateNodeFailure("E01");
    monitor.recoverNodeFromFailure("E01");

    EXPECT_TRUE(monitor.getEdgeNode("E01")->isAvailable());
    EXPECT_EQ(monitor.getTotalNodeRecoveries(), 1U);
    EXPECT_EQ(monitor.getAvailableNodeCount(), 1U);
}

TEST_F(ResourceMonitorTest, RecoverUnknownNodeIsNoOp) {
    EXPECT_NO_THROW(monitor.recoverNodeFromFailure("GHOST"));
    EXPECT_EQ(monitor.getTotalNodeRecoveries(), 0U);
}

TEST_F(ResourceMonitorTest, StatusCallbackFiresOnFailureAndRecovery) {
    monitor.registerEdgeNode(makeEdge("E01"));

    std::vector<std::pair<std::string, bool>> events;
    monitor.registerStatusCallback(
        [&events](const std::string& edge_id, bool available) {
            events.emplace_back(edge_id, available);
        });

    monitor.simulateNodeFailure("E01");
    monitor.recoverNodeFromFailure("E01");

    ASSERT_EQ(events.size(), 2U);
    EXPECT_EQ(events[0].first, "E01");
    EXPECT_FALSE(events[0].second);
    EXPECT_EQ(events[1].first, "E01");
    EXPECT_TRUE(events[1].second);
}

TEST_F(ResourceMonitorTest, CheckEdgeNodeHealthReportsCurrentAvailability) {
    monitor.registerEdgeNode(makeEdge("E01"));
    monitor.registerEdgeNode(makeEdge("E02"));
    monitor.simulateNodeFailure("E02");

    std::map<std::string, bool> health;
    monitor.registerStatusCallback(
        [&health](const std::string& edge_id, bool available) {
            health[edge_id] = available;
        });

    monitor.checkEdgeNodeHealth();

    ASSERT_EQ(health.size(), 2U);
    EXPECT_TRUE(health["E01"]);
    EXPECT_FALSE(health["E02"]);
}

TEST_F(ResourceMonitorTest, CheckEdgeNodeHealthWithNoCallbackDoesNotThrow) {
    monitor.registerEdgeNode(makeEdge("E01"));
    EXPECT_NO_THROW(monitor.checkEdgeNodeHealth());
}

TEST_F(ResourceMonitorTest, UpdateResourceMetricsOnlyAffectsAvailableNodes) {
    monitor.registerEdgeNode(makeEdge("E01"));
    monitor.registerEdgeNode(makeEdge("E02"));
    monitor.simulateNodeFailure("E02");

    // Should not throw regardless of mixed availability, and should
    // leave the failed node's availability flag untouched.
    EXPECT_NO_THROW(monitor.updateResourceMetrics());
    EXPECT_FALSE(monitor.getEdgeNode("E02")->isAvailable());
}
