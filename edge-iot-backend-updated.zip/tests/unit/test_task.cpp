#include <gtest/gtest.h>
#include "task/task.h"

#include <thread>
#include <chrono>

namespace {

Task::TaskRequirements makeRequirements(int64_t deadline_ms) {
    Task::TaskRequirements req;
    req.cpu_percent = 10.0;
    req.ram_mb = 50.0;
    req.bandwidth_mbps = 1.0;
    req.deadline_ms = deadline_ms;
    req.priority = Task::TaskPriority::HIGH;
    return req;
}

}  // namespace

TEST(TaskTest, ConstructorSetsFieldsCorrectly) {
    const json sensor_data = {{"distance_cm", 35.2}};
    Task task("T001", "US001", "ultrasonic", makeRequirements(100), sensor_data);

    EXPECT_EQ(task.getTaskId(), "T001");
    EXPECT_EQ(task.getDeviceId(), "US001");
    EXPECT_EQ(task.getSensorType(), "ultrasonic");
    EXPECT_EQ(task.getStatus(), Task::TaskStatus::CREATED);
    EXPECT_EQ(task.getAssignedEdgeId(), "");
}

TEST(TaskTest, DeadlineNotExceededImmediatelyAfterCreation) {
    Task task("T002", "US001", "ultrasonic", makeRequirements(10000), json::object());
    EXPECT_FALSE(task.isDeadlineExceeded());
}

TEST(TaskTest, DeadlineExceededAfterShortTimeout) {
    Task task("T003", "US001", "ultrasonic", makeRequirements(1), json::object());
    std::this_thread::sleep_for(std::chrono::milliseconds(20));
    EXPECT_TRUE(task.isDeadlineExceeded());
}

TEST(TaskTest, StatusTransitionsPersist) {
    Task task("T004", "US001", "ultrasonic", makeRequirements(100), json::object());
    task.setStatus(Task::TaskStatus::QUEUED);
    EXPECT_EQ(task.getStatus(), Task::TaskStatus::QUEUED);

    task.setAssignedEdgeId("E01");
    EXPECT_EQ(task.getAssignedEdgeId(), "E01");
}

TEST(TaskTest, JsonRoundTripPreservesRequirements) {
    Task original("T005", "CAM001", "camera", makeRequirements(50), json{{"frame_number", 1}});
    original.setAssignedEdgeId("E02");
    original.setStatus(Task::TaskStatus::COMPLETED);

    const json serialized = original.toJson();
    const Task restored = Task::fromJson(serialized);

    EXPECT_EQ(restored.getTaskId(), original.getTaskId());
    EXPECT_EQ(restored.getDeviceId(), original.getDeviceId());
    EXPECT_EQ(restored.getSensorType(), original.getSensorType());
    EXPECT_EQ(restored.getAssignedEdgeId(), original.getAssignedEdgeId());
    EXPECT_EQ(restored.getStatus(), original.getStatus());
    EXPECT_DOUBLE_EQ(restored.getRequirements().cpu_percent, original.getRequirements().cpu_percent);
}

TEST(TaskTest, PriorityOrderingMatchesSpecExample) {
    // Spec §13: T103(CRITICAL) > T101(HIGH) > T104(MEDIUM) > T102(LOW)
    EXPECT_LT(Task::TaskPriority::LOW, Task::TaskPriority::MEDIUM);
    EXPECT_LT(Task::TaskPriority::MEDIUM, Task::TaskPriority::HIGH);
    EXPECT_LT(Task::TaskPriority::HIGH, Task::TaskPriority::CRITICAL);
}

TEST(TaskTest, JsonRoundTripHandlesMissingOptionalFields) {
    Task original("T006", "DEV6", "temperature", makeRequirements(1000), json::object());
    json serialized = original.toJson();
    serialized.erase("assigned_edge_id");
    serialized.erase("status");
    const Task restored = Task::fromJson(serialized);
    EXPECT_EQ(restored.getAssignedEdgeId(), "");
    EXPECT_EQ(restored.getStatus(), Task::TaskStatus::CREATED);
}

TEST(TaskTest, AllLifecycleStatusesCanBeStored) {
    Task task("T007", "DEV7", "temperature", makeRequirements(1000), json::object());
    const Task::TaskStatus statuses[] = {
        Task::TaskStatus::SCHEDULED, Task::TaskStatus::ALLOCATED,
        Task::TaskStatus::QUEUED, Task::TaskStatus::RUNNING,
        Task::TaskStatus::COMPLETED, Task::TaskStatus::FAILED,
        Task::TaskStatus::DEADLINE_MISSED, Task::TaskStatus::REALLOCATED
    };
    for (const auto status : statuses) {
        task.setStatus(status);
        EXPECT_EQ(task.getStatus(), status);
    }
}

TEST(TaskTest, GetSensorDataReturnsOriginalPayload) {
    const json payload = {{"temperature_celsius", 22.5}};
    Task task("T008", "DEV8", "temperature", makeRequirements(1000), payload);
    EXPECT_EQ(task.getSensorData()["temperature_celsius"], 22.5);
}

TEST(TaskTest, GetRemainingTimeMsDecreasesOverTime) {
    Task task("T009", "DEV9", "temperature", makeRequirements(10000), json::object());
    const int64_t first = task.getRemainingTimeMs();
    std::this_thread::sleep_for(std::chrono::milliseconds(15));
    const int64_t second = task.getRemainingTimeMs();
    EXPECT_LT(second, first);
}

TEST(TaskTest, WaitingTimeEqualsElapsedTimeBeforeExecutionStarts) {
    Task task("T010", "DEV10", "temperature", makeRequirements(10000), json::object());
    std::this_thread::sleep_for(std::chrono::milliseconds(10));
    // getExecutionStartTime() is still default-constructed (epoch), so
    // getWaitingTimeMs() falls back to elapsed time since creation.
    EXPECT_GE(task.getWaitingTimeMs(), 10);
}

TEST(TaskTest, WaitingTimeReflectsGapBetweenCreationAndExecutionStart) {
    Task task("T011", "DEV11", "temperature", makeRequirements(10000), json::object());
    std::this_thread::sleep_for(std::chrono::milliseconds(15));
    task.setExecutionStartTime(std::chrono::system_clock::now());

    const int64_t waiting = task.getWaitingTimeMs();
    EXPECT_GE(waiting, 10);
    EXPECT_LT(waiting, 1000);  // sanity bound, not exact due to scheduling jitter
}

TEST(TaskTest, GetElapsedTimeMsNeverNegative) {
    Task task("T012", "DEV12", "temperature", makeRequirements(1000), json::object());
    EXPECT_GE(task.getElapsedTimeMs(), 0);
}

TEST(TaskTest, DefaultAssignedEdgeIdIsEmptyString) {
    Task task("T013", "DEV13", "temperature", makeRequirements(1000), json::object());
    EXPECT_TRUE(task.getAssignedEdgeId().empty());
}

TEST(TaskTest, ToJsonIncludesRequirementsFields) {
    Task task("T014", "DEV14", "temperature", makeRequirements(750), json::object());
    const json serialized = task.toJson();
    EXPECT_EQ(serialized["deadline_ms"], 750);
    EXPECT_DOUBLE_EQ(serialized["cpu_percent"].get<double>(), 10.0);
}

TEST(TaskTest, DeadlineExactlyAtBoundaryIsNotYetExceeded) {
    // isDeadlineExceeded() uses strict '>' so equality at the boundary
    // must NOT count as exceeded.
    Task task("T015", "DEV15", "temperature", makeRequirements(1000000), json::object());
    EXPECT_FALSE(task.isDeadlineExceeded());
}
