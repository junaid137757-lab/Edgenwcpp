#include <gtest/gtest.h>
#include "iot_device/sensor_simulator.h"

#include <thread>
#include <chrono>

namespace {

IoTDevice::DeviceConfig makeConfig(
    const std::string& id, IoTDevice::DeviceType type, double interval_ms = 100.0) {
    IoTDevice::DeviceConfig config;
    config.device_id = id;
    config.type = type;
    config.data_generation_interval_ms = interval_ms;
    config.data_variance = 0.1;
    return config;
}

}  // namespace

// ---------------------------------------------------------------------
// IoTDevice base-class behavior (exercised through concrete subclasses,
// since IoTDevice::generateSensorData is pure virtual).
// ---------------------------------------------------------------------

TEST(IoTDeviceTest, ConstructorSetsIdTypeAndActiveState) {
    UltrasonicSensor sensor(makeConfig("US01", IoTDevice::DeviceType::ULTRASONIC));
    EXPECT_EQ(sensor.getDeviceId(), "US01");
    EXPECT_EQ(sensor.getType(), IoTDevice::DeviceType::ULTRASONIC);
    EXPECT_TRUE(sensor.isActive());
}

TEST(IoTDeviceTest, SetActiveTogglesState) {
    UltrasonicSensor sensor(makeConfig("US01", IoTDevice::DeviceType::ULTRASONIC));
    sensor.setActive(false);
    EXPECT_FALSE(sensor.isActive());
    sensor.setActive(true);
    EXPECT_TRUE(sensor.isActive());
}

TEST(IoTDeviceTest, InactiveDeviceShouldNotGenerateData) {
    UltrasonicSensor sensor(makeConfig("US01", IoTDevice::DeviceType::ULTRASONIC, 0.0));
    sensor.setActive(false);
    EXPECT_FALSE(sensor.shouldGenerateData());
}

TEST(IoTDeviceTest, ActiveDeviceGeneratesDataAfterIntervalElapses) {
    UltrasonicSensor sensor(makeConfig("US01", IoTDevice::DeviceType::ULTRASONIC, 5.0));
    std::this_thread::sleep_for(std::chrono::milliseconds(20));
    EXPECT_TRUE(sensor.shouldGenerateData());
}

TEST(IoTDeviceTest, UpdateLastGenerationTimeResetsShouldGenerateWindow) {
    UltrasonicSensor sensor(makeConfig("US01", IoTDevice::DeviceType::ULTRASONIC, 1000.0));
    sensor.updateLastGenerationTime();
    EXPECT_FALSE(sensor.shouldGenerateData());
}

TEST(IoTDeviceTest, TypeStringMatchesEachDeviceType) {
    EXPECT_EQ(UltrasonicSensor(makeConfig("A", IoTDevice::DeviceType::ULTRASONIC)).getTypeString(), "ultrasonic");
    EXPECT_EQ(TemperatureSensor(makeConfig("B", IoTDevice::DeviceType::TEMPERATURE)).getTypeString(), "temperature");
    EXPECT_EQ(CameraSensor(makeConfig("C", IoTDevice::DeviceType::CAMERA)).getTypeString(), "camera");
    EXPECT_EQ(HumiditySensor(makeConfig("D", IoTDevice::DeviceType::HUMIDITY)).getTypeString(), "humidity");
    EXPECT_EQ(PressureSensor(makeConfig("E", IoTDevice::DeviceType::PRESSURE)).getTypeString(), "pressure");
}

// ---------------------------------------------------------------------
// Sensor-specific payload generation and clamping behavior.
// ---------------------------------------------------------------------

TEST(SensorSimulatorTest, UltrasonicPayloadHasExpectedFieldsAndBounds) {
    UltrasonicSensor sensor(makeConfig("US01", IoTDevice::DeviceType::ULTRASONIC));
    for (int i = 0; i < 20; ++i) {
        const json payload = sensor.generateSensorData();
        ASSERT_TRUE(payload.contains("distance_cm"));
        const double distance = payload["distance_cm"].get<double>();
        EXPECT_GE(distance, 5.0);
        EXPECT_LE(distance, 500.0);
        EXPECT_EQ(payload["sensor_type"], "ultrasonic");
        EXPECT_EQ(payload["device_id"], "US01");
        EXPECT_TRUE(payload.contains("timestamp"));
    }
}

TEST(SensorSimulatorTest, TemperaturePayloadStaysWithinClampedRange) {
    TemperatureSensor sensor(makeConfig("T01", IoTDevice::DeviceType::TEMPERATURE));
    for (int i = 0; i < 20; ++i) {
        const json payload = sensor.generateSensorData();
        const double temp = payload["temperature_celsius"].get<double>();
        EXPECT_GE(temp, -50.0);
        EXPECT_LE(temp, 100.0);
        EXPECT_EQ(payload["sensor_type"], "temperature");
    }
}

TEST(SensorSimulatorTest, CameraPayloadIncrementsFrameCounter) {
    CameraSensor sensor(makeConfig("CAM01", IoTDevice::DeviceType::CAMERA));
    const json first = sensor.generateSensorData();
    const json second = sensor.generateSensorData();

    EXPECT_EQ(first["frame_number"], 1);
    EXPECT_EQ(second["frame_number"], 2);
    EXPECT_EQ(first["resolution_width"], 1920);
    EXPECT_EQ(first["resolution_height"], 1080);
    EXPECT_EQ(first["sensor_type"], "camera");
}

TEST(SensorSimulatorTest, HumidityPayloadStaysWithinClampedRange) {
    HumiditySensor sensor(makeConfig("H01", IoTDevice::DeviceType::HUMIDITY));
    for (int i = 0; i < 20; ++i) {
        const json payload = sensor.generateSensorData();
        const double humidity = payload["humidity_percent"].get<double>();
        EXPECT_GE(humidity, 0.0);
        EXPECT_LE(humidity, 100.0);
        EXPECT_EQ(payload["sensor_type"], "humidity");
    }
}

TEST(SensorSimulatorTest, PressurePayloadStaysWithinClampedRange) {
    PressureSensor sensor(makeConfig("P01", IoTDevice::DeviceType::PRESSURE));
    for (int i = 0; i < 20; ++i) {
        const json payload = sensor.generateSensorData();
        const double pressure = payload["pressure_hpa"].get<double>();
        EXPECT_GE(pressure, 950.0);
        EXPECT_LE(pressure, 1050.0);
        EXPECT_EQ(payload["sensor_type"], "pressure");
    }
}
