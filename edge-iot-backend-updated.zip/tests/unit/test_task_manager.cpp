#include <gtest/gtest.h>
#include "task/task_manager.h"

#include <vector>
#include <string>

TEST(TaskManagerTest, InitialStateHasNoTasksAndZeroCounters) {
    TaskManager manager;
    EXPECT_FALSE(manager.hasTasksInQueue());
    EXPECT_EQ(manager.getQueueSize(), 0U);
    EXPECT_EQ(manager.getTotalTasksCreated(), 0U);
    EXPECT_EQ(manager.getTotalTasksProcessed(), 0U);
}

TEST(TaskManagerTest, GenerateTaskIdProducesSequentialZeroPaddedIds) {
    TaskManager manager;
    EXPECT_EQ(manager.generateTaskId(), "T000001");
    EXPECT_EQ(manager.generateTaskId(), "T000002");
    EXPECT_EQ(manager.generateTaskId(), "T000003");
}

TEST(TaskManagerTest, CreateTaskFromSensorDataIncrementsCreatedCounter) {
    TaskManager manager;
    const auto task = manager.createTaskFromSensorData(
        "DEV1", "ultrasonic", json{{"distance_cm", 40.0}});

    ASSERT_NE(task, nullptr);
    EXPECT_EQ(task->getDeviceId(), "DEV1");
    EXPECT_EQ(task->getSensorType(), "ultrasonic");
    EXPECT_EQ(manager.getTotalTasksCreated(), 1U);
}

TEST(TaskManagerTest, CreateTaskFromUnknownSensorTypeStillProducesTask) {
    // TaskProfile::getRequirements falls back to safe defaults for an
    // unrecognized sensor type rather than throwing.
    TaskManager manager;
    const auto task = manager.createTaskFromSensorData(
        "DEV9", "unknown_sensor_type_xyz", json::object());
    ASSERT_NE(task, nullptr);
    EXPECT_EQ(task->getSensorType(), "unknown_sensor_type_xyz");
}

TEST(TaskManagerTest, EnqueueAndDequeuePreservesFifoOrder) {
    TaskManager manager;
    auto task1 = manager.createTaskFromSensorData("DEV1", "temperature", json::object());
    auto task2 = manager.createTaskFromSensorData("DEV1", "temperature", json::object());

    manager.enqueueTask(task1);
    manager.enqueueTask(task2);
    EXPECT_TRUE(manager.hasTasksInQueue());
    EXPECT_EQ(manager.getQueueSize(), 2U);

    const auto first = manager.dequeueTask();
    ASSERT_NE(first, nullptr);
    EXPECT_EQ(first->getTaskId(), task1->getTaskId());
    EXPECT_EQ(manager.getTotalTasksProcessed(), 1U);

    const auto second = manager.dequeueTask();
    ASSERT_NE(second, nullptr);
    EXPECT_EQ(second->getTaskId(), task2->getTaskId());
    EXPECT_EQ(manager.getTotalTasksProcessed(), 2U);
}

TEST(TaskManagerTest, DequeueOnEmptyQueueReturnsNullptr) {
    TaskManager manager;
    EXPECT_EQ(manager.dequeueTask(), nullptr);
    EXPECT_EQ(manager.getTotalTasksProcessed(), 0U);
}

TEST(TaskManagerTest, RegisteredCallbackFiresOnTaskCreation) {
    TaskManager manager;
    std::vector<std::string> created_ids;

    manager.registerTaskCreationCallback(
        [&created_ids](std::shared_ptr<Task> task) {
            created_ids.push_back(task->getTaskId());
        });

    manager.createTaskFromSensorData("DEV1", "camera", json::object());
    manager.createTaskFromSensorData("DEV2", "camera", json::object());

    ASSERT_EQ(created_ids.size(), 2U);
}

TEST(TaskManagerTest, UnregisterCallbackStopsFutureNotifications) {
    TaskManager manager;
    int call_count = 0;

    manager.registerTaskCreationCallback(
        [&call_count](std::shared_ptr<Task>) { ++call_count; });
    manager.createTaskFromSensorData("DEV1", "camera", json::object());
    EXPECT_EQ(call_count, 1);

    manager.unregisterTaskCreationCallback();
    manager.createTaskFromSensorData("DEV1", "camera", json::object());
    EXPECT_EQ(call_count, 1);  // unchanged: callback no longer fires
}

TEST(TaskManagerTest, CreatingTaskWithoutCallbackRegisteredDoesNotThrow) {
    TaskManager manager;
    EXPECT_NO_THROW(manager.createTaskFromSensorData("DEV1", "humidity", json::object()));
}

TEST(TaskManagerTest, GenerateTaskIdSequenceContinuesAcrossManyCalls) {
    TaskManager manager;
    for (int i = 1; i <= 15; ++i) {
        std::ostringstream expected;
        expected << 'T' << std::setw(6) << std::setfill('0') << i;
        EXPECT_EQ(manager.generateTaskId(), expected.str());
    }
}

TEST(TaskManagerTest, EachCreatedTaskGetsAUniqueId) {
    TaskManager manager;
    auto t1 = manager.createTaskFromSensorData("DEV1", "temperature", json::object());
    auto t2 = manager.createTaskFromSensorData("DEV1", "temperature", json::object());
    EXPECT_NE(t1->getTaskId(), t2->getTaskId());
}

TEST(TaskManagerTest, QueueSizeDecreasesAsTasksAreDequeued) {
    TaskManager manager;
    manager.enqueueTask(manager.createTaskFromSensorData("DEV1", "temperature", json::object()));
    manager.enqueueTask(manager.createTaskFromSensorData("DEV1", "temperature", json::object()));
    ASSERT_EQ(manager.getQueueSize(), 2U);
    manager.dequeueTask();
    EXPECT_EQ(manager.getQueueSize(), 1U);
}

TEST(TaskManagerTest, ReRegisteringCallbackReplacesThePreviousOne) {
    TaskManager manager;
    int first_calls = 0;
    int second_calls = 0;

    manager.registerTaskCreationCallback([&first_calls](std::shared_ptr<Task>) { ++first_calls; });
    manager.registerTaskCreationCallback([&second_calls](std::shared_ptr<Task>) { ++second_calls; });

    manager.createTaskFromSensorData("DEV1", "temperature", json::object());
    EXPECT_EQ(first_calls, 0);
    EXPECT_EQ(second_calls, 1);
}

TEST(TaskManagerTest, TaskCreatedHasCreatedStatusInitially) {
    TaskManager manager;
    auto task = manager.createTaskFromSensorData("DEV1", "camera", json::object());
    EXPECT_EQ(task->getStatus(), Task::TaskStatus::CREATED);
}
