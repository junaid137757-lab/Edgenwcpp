#include <gtest/gtest.h>
#include "simulation_config.h"

#include <vector>
#include <cstring>

namespace {

// argv entries must be non-const char* per the C convention parseArgs
// mirrors; this helper builds a mutable argv array from string
// literals for a single test call.
class Argv {
public:
    explicit Argv(std::vector<std::string> args) : storage_(std::move(args)) {
        for (auto& s : storage_) {
            pointers_.push_back(s.data());
        }
    }
    int argc() const { return static_cast<int>(pointers_.size()); }
    char** argv() { return pointers_.data(); }

private:
    std::vector<std::string> storage_;
    std::vector<char*> pointers_;
};

}  // namespace

TEST(SimulationConfigTest, DefaultsMatchSpecDefaults) {
    SimulationConfig config;
    EXPECT_EQ(config.device_count, 100U);
    EXPECT_EQ(config.edge_node_count, 10U);
    EXPECT_EQ(config.task_count, 10000U);
    EXPECT_EQ(config.scheduling, "priority_based");
    EXPECT_FALSE(config.interactive);
    EXPECT_FALSE(config.use_mqtt);
    EXPECT_FALSE(config.verbose);
}

TEST(SimulationConfigTest, NoArgsReturnsDefaults) {
    Argv args({"edge_iot_sim"});
    const SimulationConfig config = SimulationConfig::parseArgs(args.argc(), args.argv());
    EXPECT_EQ(config.device_count, 100U);
}

TEST(SimulationConfigTest, ShortFlagsOverrideDeviceEdgeTaskCounts) {
    Argv args({"edge_iot_sim", "-d", "5", "-e", "2", "-t", "50"});
    const SimulationConfig config = SimulationConfig::parseArgs(args.argc(), args.argv());
    EXPECT_EQ(config.device_count, 5U);
    EXPECT_EQ(config.edge_node_count, 2U);
    EXPECT_EQ(config.task_count, 50U);
}

TEST(SimulationConfigTest, LongFlagsOverrideDeviceEdgeTaskCounts) {
    Argv args({"edge_iot_sim", "--devices", "7", "--edges", "3", "--tasks", "99"});
    const SimulationConfig config = SimulationConfig::parseArgs(args.argc(), args.argv());
    EXPECT_EQ(config.device_count, 7U);
    EXPECT_EQ(config.edge_node_count, 3U);
    EXPECT_EQ(config.task_count, 99U);
}

TEST(SimulationConfigTest, SchedulerFlagSetsSchedulingString) {
    Argv args({"edge_iot_sim", "--scheduler", "edf"});
    const SimulationConfig config = SimulationConfig::parseArgs(args.argc(), args.argv());
    EXPECT_EQ(config.scheduling, "edf");
}

TEST(SimulationConfigTest, InteractiveFlagSetsBooleanTrue) {
    Argv args({"edge_iot_sim", "--interactive"});
    const SimulationConfig config = SimulationConfig::parseArgs(args.argc(), args.argv());
    EXPECT_TRUE(config.interactive);
}

TEST(SimulationConfigTest, DelayFlagOverridesCycleDelay) {
    Argv args({"edge_iot_sim", "--delay", "250"});
    const SimulationConfig config = SimulationConfig::parseArgs(args.argc(), args.argv());
    EXPECT_EQ(config.cycle_delay_ms, 250U);
}

TEST(SimulationConfigTest, MqttFlagEnablesMqttAndSetsBroker) {
    Argv args({"edge_iot_sim", "--mqtt", "--broker", "tcp://example:1883"});
    const SimulationConfig config = SimulationConfig::parseArgs(args.argc(), args.argv());
    EXPECT_TRUE(config.use_mqtt);
    EXPECT_EQ(config.mqtt_broker, "tcp://example:1883");
}

TEST(SimulationConfigTest, DbFlagOverridesDbPath) {
    Argv args({"edge_iot_sim", "--db", "custom.db"});
    const SimulationConfig config = SimulationConfig::parseArgs(args.argc(), args.argv());
    EXPECT_EQ(config.db_path, "custom.db");
}

TEST(SimulationConfigTest, VerboseFlagSetsBooleanTrue) {
    Argv args({"edge_iot_sim", "--verbose"});
    const SimulationConfig config = SimulationConfig::parseArgs(args.argc(), args.argv());
    EXPECT_TRUE(config.verbose);
}

TEST(SimulationConfigTest, MultipleFlagsCombineCorrectly) {
    Argv args({"edge_iot_sim", "-d", "3", "--verbose", "--scheduler", "round_robin"});
    const SimulationConfig config = SimulationConfig::parseArgs(args.argc(), args.argv());
    EXPECT_EQ(config.device_count, 3U);
    EXPECT_TRUE(config.verbose);
    EXPECT_EQ(config.scheduling, "round_robin");
}

TEST(SimulationConfigTest, FlagMissingRequiredValueIsTreatedAsUnknownArgument) {
    // "-d" with no following value fails the has_next check, so it
    // falls through to the "Unknown argument" branch, which exits(1).
    Argv args({"edge_iot_sim", "-d"});
    EXPECT_EXIT(
        SimulationConfig::parseArgs(args.argc(), args.argv()),
        ::testing::ExitedWithCode(1),
        "");
}

TEST(SimulationConfigTest, UnknownArgumentExitsWithCodeOne) {
    Argv args({"edge_iot_sim", "--totally-not-a-real-flag"});
    EXPECT_EXIT(
        SimulationConfig::parseArgs(args.argc(), args.argv()),
        ::testing::ExitedWithCode(1),
        "");
}

TEST(SimulationConfigTest, HelpFlagExitsWithCodeZero) {
    Argv args({"edge_iot_sim", "-h"});
    EXPECT_EXIT(
        SimulationConfig::parseArgs(args.argc(), args.argv()),
        ::testing::ExitedWithCode(0),
        "");
}

TEST(SimulationConfigTest, LongHelpFlagExitsWithCodeZero) {
    Argv args({"edge_iot_sim", "--help"});
    EXPECT_EXIT(
        SimulationConfig::parseArgs(args.argc(), args.argv()),
        ::testing::ExitedWithCode(0),
        "");
}

TEST(SimulationConfigTest, PrintUsageRunsWithoutThrowing) {
    EXPECT_NO_THROW(SimulationConfig::printUsage("edge_iot_sim"));
}
