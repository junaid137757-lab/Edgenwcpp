#include <gtest/gtest.h>
#include "database/database_manager.h"
#include "edge/edge_node.h"
#include "task/task.h"
#include "common/test_db_helper.h"

namespace {

Task::TaskRequirements makeRequirements() {
    Task::TaskRequirements req;
    req.cpu_percent = 12.5;
    req.ram_mb = 64.0;
    req.bandwidth_mbps = 2.0;
    req.deadline_ms = 250;
    req.priority = Task::TaskPriority::HIGH;
    return req;
}

std::shared_ptr<EdgeNode> makeEdge(const std::string& id) {
    EdgeNode::ResourceCapacity cap;
    cap.cpu_percent = 100.0;
    cap.ram_mb = 4096.0;
    cap.bandwidth_mbps = 40.0;
    cap.latency_ms = 12;
    return std::make_shared<EdgeNode>(id, cap);
}

// Shared fixture: DatabaseManager is a singleton (MISRA deviation D6),
// so every test case resets simulation data first rather than relying
// on a fresh instance, keeping cases independent of execution order.
class DatabaseManagerTest : public ::testing::Test {
protected:
    void SetUp() override {
        ensureTestDatabaseInitialized();
        db = &DatabaseManager::getInstance();
        db->resetSimulationData();
    }

    DatabaseManager* db = nullptr;
};

}  // namespace

TEST_F(DatabaseManagerTest, InitializeOnInMemoryDbSucceedsAndReportsInitialized) {
    EXPECT_TRUE(db->isInitialized());
}

TEST_F(DatabaseManagerTest, InitializeWithUnwritablePathFails) {
    // A path inside a directory that does not exist: sqlite3_open can
    // still succeed lazily for some paths, but a directory that cannot
    // exist as a file component reliably fails to open for writing.
    DatabaseManager& fresh = DatabaseManager::getInstance();
    const bool result = fresh.initialize("/nonexistent_dir_xyz/sub/sim.db");
    EXPECT_FALSE(result);

    // Restore the shared in-memory DB for subsequent tests in this binary.
    fresh.initialize(":memory:");
}

TEST_F(DatabaseManagerTest, SaveAndRetrieveDeviceRoundTrips) {
    EXPECT_TRUE(db->saveDevice("DEV1", "ultrasonic"));
    // saveDevice has no getter of its own; confirmed indirectly via
    // saveTask's foreign-key constraint succeeding below.
}

TEST_F(DatabaseManagerTest, SaveTaskProfilePersistsWithoutError) {
    EXPECT_TRUE(db->saveTaskProfile("ultrasonic", makeRequirements()));
}

TEST_F(DatabaseManagerTest, SaveEdgeNodePersistsWithoutError) {
    EXPECT_TRUE(db->saveEdgeNode(makeEdge("E01")));
}

TEST_F(DatabaseManagerTest, SaveEdgeNodeWithNullptrFails) {
    EXPECT_FALSE(db->saveEdgeNode(nullptr));
}

TEST_F(DatabaseManagerTest, SaveTaskThenGetTaskRoundTripsAllFields) {
    db->saveDevice("DEV1", "temperature");
    auto task = std::make_shared<Task>("T001", "DEV1", "temperature", makeRequirements(), json::object());
    task->setStatus(Task::TaskStatus::QUEUED);

    ASSERT_TRUE(db->saveTask(task));

    const auto fetched = db->getTask("T001");
    ASSERT_NE(fetched, nullptr);
    EXPECT_EQ(fetched->getTaskId(), "T001");
    EXPECT_EQ(fetched->getDeviceId(), "DEV1");
    EXPECT_EQ(fetched->getSensorType(), "temperature");
    EXPECT_EQ(fetched->getStatus(), Task::TaskStatus::QUEUED);
    EXPECT_DOUBLE_EQ(fetched->getRequirements().cpu_percent, 12.5);
}

TEST_F(DatabaseManagerTest, SaveTaskWithNullptrFails) {
    EXPECT_FALSE(db->saveTask(nullptr));
}

TEST_F(DatabaseManagerTest, GetTaskForUnknownIdReturnsNullptr) {
    EXPECT_EQ(db->getTask("DOES_NOT_EXIST"), nullptr);
}

TEST_F(DatabaseManagerTest, UpdateTaskStatusChangesStoredStatus) {
    db->saveDevice("DEV1", "temperature");
    auto task = std::make_shared<Task>("T002", "DEV1", "temperature", makeRequirements(), json::object());
    db->saveTask(task);

    EXPECT_TRUE(db->updateTaskStatus("T002", Task::TaskStatus::COMPLETED));

    const auto fetched = db->getTask("T002");
    ASSERT_NE(fetched, nullptr);
    EXPECT_EQ(fetched->getStatus(), Task::TaskStatus::COMPLETED);
}

TEST_F(DatabaseManagerTest, GetAllTasksReturnsEverySavedTask) {
    db->saveDevice("DEV1", "temperature");
    db->saveTask(std::make_shared<Task>("T010", "DEV1", "temperature", makeRequirements(), json::object()));
    db->saveTask(std::make_shared<Task>("T011", "DEV1", "temperature", makeRequirements(), json::object()));

    const auto tasks = db->getAllTasks();
    EXPECT_EQ(tasks.size(), 2U);
}

TEST_F(DatabaseManagerTest, GetAllTasksOnEmptyTableReturnsEmptyVector) {
    EXPECT_TRUE(db->getAllTasks().empty());
}

TEST_F(DatabaseManagerTest, SaveAllocationSucceedsForExistingTask) {
    db->saveDevice("DEV1", "temperature");
    db->saveTask(std::make_shared<Task>("T020", "DEV1", "temperature", makeRequirements(), json::object()));
    EXPECT_TRUE(db->saveAllocation("T020", "E01", 0.87));
}

TEST_F(DatabaseManagerTest, SaveAllocationFailureRecordsReason) {
    db->saveDevice("DEV1", "temperature");
    db->saveTask(std::make_shared<Task>("T021", "DEV1", "temperature", makeRequirements(), json::object()));
    EXPECT_TRUE(db->saveAllocationFailure("T021", "no feasible edge"));
}

TEST_F(DatabaseManagerTest, GetTaskAllocationHistoryReflectsSavedAllocations) {
    db->saveDevice("DEV1", "temperature");
    db->saveTask(std::make_shared<Task>("T030", "DEV1", "temperature", makeRequirements(), json::object()));
    db->saveAllocation("T030", "E01", 0.75);
    db->saveTask(std::make_shared<Task>("T031", "DEV1", "temperature", makeRequirements(), json::object()));
    db->saveAllocationFailure("T031", "overloaded");

    const auto history = db->getTaskAllocationHistory();
    ASSERT_EQ(history.size(), 2U);
    // Most recent first (ORDER BY id DESC).
    EXPECT_EQ(history[0]["task_id"], "T031");
    EXPECT_FALSE(history[0]["success"].get<bool>());
    EXPECT_EQ(history[0]["reason"], "overloaded");
    EXPECT_EQ(history[1]["task_id"], "T030");
    EXPECT_TRUE(history[1]["success"].get<bool>());
}

TEST_F(DatabaseManagerTest, SaveTaskExecutionPersistsSuccessAndFailure) {
    db->saveDevice("DEV1", "temperature");
    db->saveTask(std::make_shared<Task>("T040", "DEV1", "temperature", makeRequirements(), json::object()));
    EXPECT_TRUE(db->saveTaskExecution("T040", 42, true));
    EXPECT_TRUE(db->saveTaskExecution("T040", 99, false));
}

TEST_F(DatabaseManagerTest, SaveResourceSnapshotAndReadBackHistory) {
    db->saveEdgeNode(makeEdge("E05"));
    EdgeNode::ResourceUsage usage;
    usage.cpu_percent = 45.0;
    usage.ram_mb = 512.0;
    usage.bandwidth_mbps = 5.0;
    EXPECT_TRUE(db->saveResourceSnapshot("E05", usage, 3));

    const auto history = db->getEdgeResourceHistory("E05");
    ASSERT_EQ(history.size(), 1U);
    EXPECT_DOUBLE_EQ(history[0]["cpu_percent"].get<double>(), 45.0);
    EXPECT_EQ(history[0]["queue_length"].get<int64_t>(), 3);
}

TEST_F(DatabaseManagerTest, GetEdgeResourceHistoryForUnknownEdgeReturnsEmpty) {
    EXPECT_TRUE(db->getEdgeResourceHistory("NO_SUCH_EDGE").empty());
}

TEST_F(DatabaseManagerTest, UpdateEdgeNodeResourcesPersistsLatestUsage) {
    db->saveEdgeNode(makeEdge("E06"));
    EdgeNode::ResourceUsage usage;
    usage.cpu_percent = 20.0;
    usage.ram_mb = 256.0;
    usage.bandwidth_mbps = 3.0;
    EXPECT_TRUE(db->updateEdgeNodeResources("E06", usage));

    // Calling it again (as would happen on every monitoring tick)
    // should replace the row rather than accumulate duplicates.
    usage.cpu_percent = 30.0;
    EXPECT_TRUE(db->updateEdgeNodeResources("E06", usage));
}

TEST_F(DatabaseManagerTest, GetSystemMetricsAggregatesAcrossTables) {
    db->saveDevice("DEV1", "temperature");
    auto task = std::make_shared<Task>("T050", "DEV1", "temperature", makeRequirements(), json::object());
    db->saveTask(task);
    db->saveAllocation("T050", "E01", 0.9);
    db->saveTaskExecution("T050", 15, true);

    const json metrics = db->getSystemMetrics();
    EXPECT_GE(metrics["total_tasks"].get<int64_t>(), 1);
    EXPECT_GE(metrics["successful_allocations"].get<int64_t>(), 1);
    EXPECT_GE(metrics["avg_execution_ms"].get<double>(), 0.0);
}

TEST_F(DatabaseManagerTest, ResetSimulationDataClearsAllTables) {
    db->saveDevice("DEV1", "temperature");
    db->saveTask(std::make_shared<Task>("T060", "DEV1", "temperature", makeRequirements(), json::object()));
    ASSERT_FALSE(db->getAllTasks().empty());

    EXPECT_TRUE(db->resetSimulationData());
    EXPECT_TRUE(db->getAllTasks().empty());
}

TEST_F(DatabaseManagerTest, CreateSchemasIsIdempotentWhenCalledAgain) {
    // CREATE TABLE IF NOT EXISTS should never fail on a second call.
    EXPECT_TRUE(db->createSchemas());
}
