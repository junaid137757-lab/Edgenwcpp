#include <gtest/gtest.h>
#include "task/task_profile.h"

// TaskProfile is a process-wide singleton (see docs/MISRA_DEVIATIONS.md
// D6), so these tests only assert properties that hold regardless of
// what other tests may have added to it, rather than assuming a fresh
// instance per test.

TEST(TaskProfileTest, GetInstanceReturnsSameObject) {
    TaskProfile& first = TaskProfile::getInstance();
    TaskProfile& second = TaskProfile::getInstance();
    EXPECT_EQ(&first, &second);
}

TEST(TaskProfileTest, AddedProfileIsRetrievable) {
    Task::TaskRequirements req;
    req.cpu_percent = 42.0;
    req.ram_mb = 123.0;
    req.bandwidth_mbps = 2.5;
    req.deadline_ms = 250;
    req.priority = Task::TaskPriority::MEDIUM;

    TaskProfile::getInstance().addProfile("test_sensor_type", req);

    ASSERT_TRUE(TaskProfile::getInstance().hasProfile("test_sensor_type"));

    const Task::TaskRequirements retrieved =
        TaskProfile::getInstance().getRequirements("test_sensor_type");

    EXPECT_DOUBLE_EQ(retrieved.cpu_percent, 42.0);
    EXPECT_DOUBLE_EQ(retrieved.ram_mb, 123.0);
    EXPECT_DOUBLE_EQ(retrieved.bandwidth_mbps, 2.5);
    EXPECT_EQ(retrieved.deadline_ms, 250);
    EXPECT_EQ(retrieved.priority, Task::TaskPriority::MEDIUM);
}

TEST(TaskProfileTest, UnknownSensorTypeReturnsConservativeFallback) {
    ASSERT_FALSE(TaskProfile::getInstance().hasProfile("nonexistent_sensor_xyz"));

    const Task::TaskRequirements fallback =
        TaskProfile::getInstance().getRequirements("nonexistent_sensor_xyz");

    // Fallback should never crash and should be a "safe" low-priority
    // profile rather than zeros or negative values.
    EXPECT_GT(fallback.cpu_percent, 0.0);
    EXPECT_GT(fallback.ram_mb, 0.0);
    EXPECT_EQ(fallback.priority, Task::TaskPriority::LOW);
}

TEST(TaskProfileTest, DefaultProfilesMatchSpecValues) {
    // Values from project spec §6. loadProfiles() with a nonexistent DB
    // path falls back to these exact built-in defaults.
    TaskProfile::getInstance().loadProfiles("/nonexistent/path/does_not_exist.db");

    ASSERT_TRUE(TaskProfile::getInstance().hasProfile("ultrasonic"));
    const Task::TaskRequirements ultrasonic = TaskProfile::getInstance().getRequirements("ultrasonic");
    EXPECT_DOUBLE_EQ(ultrasonic.cpu_percent, 10.0);
    EXPECT_DOUBLE_EQ(ultrasonic.ram_mb, 50.0);
    EXPECT_DOUBLE_EQ(ultrasonic.bandwidth_mbps, 1.0);
    EXPECT_EQ(ultrasonic.deadline_ms, 100);

    ASSERT_TRUE(TaskProfile::getInstance().hasProfile("camera"));
    const Task::TaskRequirements camera = TaskProfile::getInstance().getRequirements("camera");
    EXPECT_DOUBLE_EQ(camera.cpu_percent, 60.0);
    EXPECT_DOUBLE_EQ(camera.ram_mb, 1024.0);
    EXPECT_EQ(camera.deadline_ms, 50);
}

TEST(TaskProfileTest, TemperatureDefaultProfileMatchesSpecValues) {
    TaskProfile::getInstance().loadProfiles("/nonexistent/path/does_not_exist.db");
    const Task::TaskRequirements temp = TaskProfile::getInstance().getRequirements("temperature");
    EXPECT_DOUBLE_EQ(temp.cpu_percent, 5.0);
    EXPECT_DOUBLE_EQ(temp.ram_mb, 20.0);
    EXPECT_DOUBLE_EQ(temp.bandwidth_mbps, 0.5);
    EXPECT_EQ(temp.deadline_ms, 500);
    EXPECT_EQ(temp.priority, Task::TaskPriority::MEDIUM);
}

TEST(TaskProfileTest, HumidityAndPressureDefaultsAreLowPriority) {
    TaskProfile::getInstance().loadProfiles("/nonexistent/path/does_not_exist.db");
    EXPECT_EQ(TaskProfile::getInstance().getRequirements("humidity").priority, Task::TaskPriority::LOW);
    EXPECT_EQ(TaskProfile::getInstance().getRequirements("pressure").priority, Task::TaskPriority::LOW);
}

TEST(TaskProfileTest, CameraIsTheOnlyCriticalPriorityDefaultProfile) {
    TaskProfile::getInstance().loadProfiles("/nonexistent/path/does_not_exist.db");
    EXPECT_EQ(TaskProfile::getInstance().getRequirements("camera").priority, Task::TaskPriority::CRITICAL);
    EXPECT_EQ(TaskProfile::getInstance().getRequirements("ultrasonic").priority, Task::TaskPriority::HIGH);
}

TEST(TaskProfileTest, AddProfileOverwritesAnExistingEntryOfTheSameType) {
    Task::TaskRequirements first;
    first.cpu_percent = 1.0;
    first.ram_mb = 1.0;
    first.bandwidth_mbps = 1.0;
    first.deadline_ms = 1;
    first.priority = Task::TaskPriority::LOW;
    TaskProfile::getInstance().addProfile("overwrite_test", first);

    Task::TaskRequirements second = first;
    second.cpu_percent = 99.0;
    TaskProfile::getInstance().addProfile("overwrite_test", second);

    EXPECT_DOUBLE_EQ(TaskProfile::getInstance().getRequirements("overwrite_test").cpu_percent, 99.0);
}

TEST(TaskProfileTest, GetAllProfilesIncludesEveryAddedEntry) {
    Task::TaskRequirements req;
    req.cpu_percent = 7.0;
    req.ram_mb = 7.0;
    req.bandwidth_mbps = 7.0;
    req.deadline_ms = 7;
    req.priority = Task::TaskPriority::LOW;
    TaskProfile::getInstance().addProfile("get_all_profiles_marker", req);

    const auto& all = TaskProfile::getInstance().getAllProfiles();
    EXPECT_NE(all.find("get_all_profiles_marker"), all.end());
}

TEST(TaskProfileTest, HasProfileIsFalseForEmptyStringSensorType) {
    EXPECT_FALSE(TaskProfile::getInstance().hasProfile(""));
}

TEST(TaskProfileTest, LoadProfilesIsSafeToCallMultipleTimes) {
    EXPECT_NO_THROW(TaskProfile::getInstance().loadProfiles("/nonexistent/a.db"));
    EXPECT_NO_THROW(TaskProfile::getInstance().loadProfiles("/nonexistent/b.db"));
    // Built-in defaults must still be present after repeated calls.
    EXPECT_TRUE(TaskProfile::getInstance().hasProfile("ultrasonic"));
}

TEST(TaskProfileTest, FallbackProfileHasReasonableDeadline) {
    const auto fallback = TaskProfile::getInstance().getRequirements("still_unknown_xyz_123");
    EXPECT_EQ(fallback.deadline_ms, 1000);
    EXPECT_GT(fallback.bandwidth_mbps, 0.0);
}
