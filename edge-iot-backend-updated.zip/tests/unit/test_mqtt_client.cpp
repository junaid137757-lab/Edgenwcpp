// This entire file is a no-op unless EDGE_IOT_MQTT_ENABLED is defined,
// which the root CMakeLists.txt only does when the Paho MQTT C++ client
// was found on the system (see docs/BUILD.md). mqtt_client.cpp itself
// is excluded from edge_iot_core's sources in that case too, so there
// would be nothing to link against otherwise.
#include "mqtt/mqtt_client.h"

#ifdef EDGE_IOT_MQTT_ENABLED

#include <gtest/gtest.h>

// NOTE ON COVERAGE SCOPE: MqttClient::onMessageArrived and the Paho
// callback adapter can only be exercised end-to-end against a live
// broker (this project's own spec, §11, treats MQTT as pure transport
// with no business logic to unit-test in isolation). These tests cover
// every branch reachable WITHOUT a broker: construction, statistics
// defaults, and the "not connected" guard clauses that connect(),
// publish(), and subscribe() all short-circuit on. Uses a
// non-routable address so connect() fails deterministically rather
// than depending on any real network.

namespace {
constexpr const char* kUnreachableBroker = "tcp://198.51.100.1:1883";  // TEST-NET-2, RFC 5737
}  // namespace

TEST(MqttClientTest, ConstructsWithZeroedStatistics) {
    MqttClient client(kUnreachableBroker, "test-client-1");
    EXPECT_EQ(client.getMessagesPublished(), 0U);
    EXPECT_EQ(client.getMessagesReceived(), 0U);
    EXPECT_FALSE(client.isConnected());
}

TEST(MqttClientTest, PublishBeforeConnectingReturnsFalse) {
    MqttClient client(kUnreachableBroker, "test-client-2");
    EXPECT_FALSE(client.publish("topic/x", json{{"k", "v"}}));
    EXPECT_EQ(client.getMessagesPublished(), 0U);
}

TEST(MqttClientTest, SubscribeBeforeConnectingReturnsFalse) {
    MqttClient client(kUnreachableBroker, "test-client-3");
    EXPECT_FALSE(client.subscribe("topic/x"));
}

TEST(MqttClientTest, DisconnectWithoutConnectingIsSafe) {
    MqttClient client(kUnreachableBroker, "test-client-4");
    EXPECT_NO_THROW(client.disconnect());
}

TEST(MqttClientTest, RegisterMessageCallbackBeforeConnectingDoesNotThrow) {
    MqttClient client(kUnreachableBroker, "test-client-5");
    EXPECT_NO_THROW(client.registerMessageCallback(
        [](const std::string&, const json&) {}));
}

TEST(MqttClientTest, DestructorDisconnectsCleanlyWithoutAnyConnection) {
    EXPECT_NO_THROW({
        MqttClient client(kUnreachableBroker, "test-client-6");
    });
}

#endif  // EDGE_IOT_MQTT_ENABLED
