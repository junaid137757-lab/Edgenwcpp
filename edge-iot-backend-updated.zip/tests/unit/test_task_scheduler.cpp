#include <gtest/gtest.h>
#include "scheduler/task_scheduler.h"
#include "edge/edge_node.h"

namespace {

std::shared_ptr<EdgeNode> makeEdge() {
    EdgeNode::ResourceCapacity cap;
    cap.cpu_percent = 100.0;
    cap.ram_mb = 16384.0;
    cap.bandwidth_mbps = 100.0;
    cap.latency_ms = 10;
    return std::make_shared<EdgeNode>("E01", cap);
}

std::shared_ptr<Task> makeTask(const std::string& id, Task::TaskPriority priority, int64_t deadline_ms) {
    Task::TaskRequirements req;
    req.cpu_percent = 1.0;
    req.ram_mb = 1.0;
    req.bandwidth_mbps = 1.0;
    req.deadline_ms = deadline_ms;
    req.priority = priority;
    return std::make_shared<Task>(id, "DEV1", "temperature", req, json::object());
}

}  // namespace

TEST(TaskSchedulerTest, FifoReturnsTasksInInsertionOrder) {
    TaskScheduler scheduler(TaskScheduler::SchedulingStrategy::FIFO);
    auto edge = makeEdge();

    scheduler.scheduleTask(edge, makeTask("T1", Task::TaskPriority::LOW, 1000));
    scheduler.scheduleTask(edge, makeTask("T2", Task::TaskPriority::CRITICAL, 1000));

    const auto first = scheduler.getNextTask(edge);
    ASSERT_NE(first, nullptr);
    EXPECT_EQ(first->getTaskId(), "T1");  // FIFO ignores priority
}

TEST(TaskSchedulerTest, PriorityBasedReturnsHighestPriorityFirst) {
    // Spec §13 example: T103(CRITICAL) -> T101(HIGH) -> T104(MEDIUM) -> T102(LOW)
    TaskScheduler scheduler(TaskScheduler::SchedulingStrategy::PRIORITY_BASED);
    auto edge = makeEdge();

    scheduler.scheduleTask(edge, makeTask("T101", Task::TaskPriority::HIGH, 1000));
    scheduler.scheduleTask(edge, makeTask("T102", Task::TaskPriority::LOW, 1000));
    scheduler.scheduleTask(edge, makeTask("T103", Task::TaskPriority::CRITICAL, 1000));
    scheduler.scheduleTask(edge, makeTask("T104", Task::TaskPriority::MEDIUM, 1000));

    EXPECT_EQ(scheduler.getNextTask(edge)->getTaskId(), "T103");
    EXPECT_EQ(scheduler.getNextTask(edge)->getTaskId(), "T101");
    EXPECT_EQ(scheduler.getNextTask(edge)->getTaskId(), "T104");
    EXPECT_EQ(scheduler.getNextTask(edge)->getTaskId(), "T102");
}

TEST(TaskSchedulerTest, EarliestDeadlineFirstOrdersByRemainingTime) {
    TaskScheduler scheduler(TaskScheduler::SchedulingStrategy::EARLIEST_DEADLINE_FIRST);
    auto edge = makeEdge();

    scheduler.scheduleTask(edge, makeTask("T_LONG", Task::TaskPriority::LOW, 5000));
    scheduler.scheduleTask(edge, makeTask("T_SHORT", Task::TaskPriority::LOW, 50));

    const auto first = scheduler.getNextTask(edge);
    ASSERT_NE(first, nullptr);
    EXPECT_EQ(first->getTaskId(), "T_SHORT");
}

TEST(TaskSchedulerTest, GetNextTaskOnEmptyQueueReturnsNull) {
    TaskScheduler scheduler(TaskScheduler::SchedulingStrategy::PRIORITY_BASED);
    auto edge = makeEdge();
    EXPECT_EQ(scheduler.getNextTask(edge), nullptr);
}

TEST(TaskSchedulerTest, RemainingTasksArePreservedAfterSelection) {
    TaskScheduler scheduler(TaskScheduler::SchedulingStrategy::PRIORITY_BASED);
    auto edge = makeEdge();

    scheduler.scheduleTask(edge, makeTask("T_LOW", Task::TaskPriority::LOW, 1000));
    scheduler.scheduleTask(edge, makeTask("T_HIGH", Task::TaskPriority::HIGH, 1000));

    scheduler.getNextTask(edge);  // Consumes T_HIGH
    EXPECT_EQ(edge->getQueueLength(), 1);  // T_LOW should remain

    const auto remaining = scheduler.getNextTask(edge);
    ASSERT_NE(remaining, nullptr);
    EXPECT_EQ(remaining->getTaskId(), "T_LOW");
}

TEST(TaskSchedulerTest, NullEdgeOrTaskIsHandledSafely) {
    TaskScheduler scheduler(TaskScheduler::SchedulingStrategy::FIFO);
    EXPECT_NO_THROW(scheduler.scheduleTask(nullptr, nullptr));
    EXPECT_EQ(scheduler.getNextTask(nullptr), nullptr);
}

TEST(TaskSchedulerTest, DefaultConstructorUsesPriorityBasedStrategy) {
    TaskScheduler scheduler;  // default argument
    EXPECT_EQ(scheduler.getStrategy(), TaskScheduler::SchedulingStrategy::PRIORITY_BASED);
}

TEST(TaskSchedulerTest, SetStrategyChangesGetStrategy) {
    TaskScheduler scheduler(TaskScheduler::SchedulingStrategy::FIFO);
    scheduler.setStrategy(TaskScheduler::SchedulingStrategy::ROUND_ROBIN_TIME_SLICE);
    EXPECT_EQ(scheduler.getStrategy(), TaskScheduler::SchedulingStrategy::ROUND_ROBIN_TIME_SLICE);
}

TEST(TaskSchedulerTest, ScheduleTaskSetsStatusToQueued) {
    TaskScheduler scheduler(TaskScheduler::SchedulingStrategy::FIFO);
    auto edge = makeEdge();
    auto task = makeTask("T1", Task::TaskPriority::LOW, 1000);

    scheduler.scheduleTask(edge, task);
    EXPECT_EQ(task->getStatus(), Task::TaskStatus::QUEUED);
}

TEST(TaskSchedulerTest, ScheduleTaskIncrementsEdgeQueueLength) {
    TaskScheduler scheduler(TaskScheduler::SchedulingStrategy::FIFO);
    auto edge = makeEdge();
    EXPECT_EQ(edge->getQueueLength(), 0);
    scheduler.scheduleTask(edge, makeTask("T1", Task::TaskPriority::LOW, 1000));
    EXPECT_EQ(edge->getQueueLength(), 1);
}

TEST(TaskSchedulerTest, TotalTasksScheduledStartsAtZero) {
    TaskScheduler scheduler(TaskScheduler::SchedulingStrategy::FIFO);
    EXPECT_EQ(scheduler.getTotalTasksScheduled(), 0U);
}

TEST(TaskSchedulerTest, SchedulingNullTaskDoesNotIncrementCounter) {
    TaskScheduler scheduler(TaskScheduler::SchedulingStrategy::FIFO);
    auto edge = makeEdge();
    scheduler.scheduleTask(edge, nullptr);
    EXPECT_EQ(scheduler.getTotalTasksScheduled(), 0U);
}

TEST(TaskSchedulerTest, PriorityTieBetweenTwoCriticalTasksPicksOneDeterministically) {
    TaskScheduler scheduler(TaskScheduler::SchedulingStrategy::PRIORITY_BASED);
    auto edge = makeEdge();
    scheduler.scheduleTask(edge, makeTask("T_A", Task::TaskPriority::CRITICAL, 1000));
    scheduler.scheduleTask(edge, makeTask("T_B", Task::TaskPriority::CRITICAL, 1000));

    const auto first = scheduler.getNextTask(edge);
    ASSERT_NE(first, nullptr);
    // Both are CRITICAL; std::max_element returns the FIRST maximal
    // element for a stable, non-strict comparator, i.e. T_A.
    EXPECT_EQ(first->getTaskId(), "T_A");
}

TEST(TaskSchedulerTest, EdfTieBetweenEqualDeadlinesPicksOneDeterministically) {
    TaskScheduler scheduler(TaskScheduler::SchedulingStrategy::EARLIEST_DEADLINE_FIRST);
    auto edge = makeEdge();
    scheduler.scheduleTask(edge, makeTask("T_A", Task::TaskPriority::LOW, 500));
    scheduler.scheduleTask(edge, makeTask("T_B", Task::TaskPriority::LOW, 500));

    const auto first = scheduler.getNextTask(edge);
    ASSERT_NE(first, nullptr);
    EXPECT_EQ(first->getTaskId(), "T_A");
}
