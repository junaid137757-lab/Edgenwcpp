#include <gtest/gtest.h>
#include "metrics/metrics_collector.h"
#include "resource/resource_allocator.h"
#include "executor/task_executor.h"
#include "edge/resource_monitor.h"
#include "scheduler/task_scheduler.h"

namespace {

std::shared_ptr<EdgeNode> makeEdge(const std::string& id) {
    EdgeNode::ResourceCapacity cap;
    cap.cpu_percent = 100.0;
    cap.ram_mb = 16384.0;
    cap.bandwidth_mbps = 100.0;
    cap.latency_ms = 15;
    return std::make_shared<EdgeNode>(id, cap);
}

}  // namespace

class MetricsCollectorTest : public ::testing::Test {
protected:
    void SetUp() override {
        monitor = std::make_shared<ResourceMonitor>();
        monitor->registerEdgeNode(makeEdge("E01"));
        monitor->registerEdgeNode(makeEdge("E02"));

        allocator = std::make_shared<ResourceAllocator>(
            monitor, ResourceAllocator::AllocationStrategy::MULTI_CONSTRAINT);

        auto scheduler = std::make_shared<TaskScheduler>(TaskScheduler::SchedulingStrategy::FIFO);
        executor = std::make_shared<TaskExecutor>(scheduler);
    }

    std::shared_ptr<ResourceMonitor> monitor;
    std::shared_ptr<ResourceAllocator> allocator;
    std::shared_ptr<TaskExecutor> executor;
};

TEST_F(MetricsCollectorTest, CollectReturnsZeroedSnapshotWithNoActivity) {
    MetricsCollector collector(allocator, executor, monitor);
    const auto snapshot = collector.collect(1.0);

    EXPECT_DOUBLE_EQ(snapshot.throughput_tasks_per_second, 0.0);
    EXPECT_DOUBLE_EQ(snapshot.deadline_miss_rate_percent, 0.0);
}

TEST_F(MetricsCollectorTest, JsonSerializationContainsAllSpecMetrics) {
    // Spec §17: latency, waiting time, deadline miss, CPU utilization,
    // load imbalance, throughput, task success rate — all 7 required.
    MetricsCollector collector(allocator, executor, monitor);
    const json result = collector.collectAsJson(1.0);

    EXPECT_TRUE(result.contains("average_latency_ms"));
    EXPECT_TRUE(result.contains("average_waiting_time_ms"));
    EXPECT_TRUE(result.contains("deadline_miss_rate_percent"));
    EXPECT_TRUE(result.contains("average_cpu_utilization_percent"));
    EXPECT_TRUE(result.contains("load_imbalance_stddev"));
    EXPECT_TRUE(result.contains("throughput_tasks_per_second"));
    EXPECT_TRUE(result.contains("task_success_rate_percent"));
}

TEST_F(MetricsCollectorTest, ZeroElapsedTimeDoesNotDivideByZero) {
    MetricsCollector collector(allocator, executor, monitor);
    EXPECT_NO_THROW({
        const auto snapshot = collector.collect(0.0);
        EXPECT_DOUBLE_EQ(snapshot.throughput_tasks_per_second, 0.0);
    });
}

TEST_F(MetricsCollectorTest, EmptyMonitorProducesZeroResourceMetrics) {
    monitor->unregisterEdgeNode("E01");
    monitor->unregisterEdgeNode("E02");
    MetricsCollector collector(allocator, executor, monitor);
    const auto snapshot = collector.collect(1.0);
    EXPECT_DOUBLE_EQ(snapshot.average_cpu_utilization_percent, 0.0);
    EXPECT_DOUBLE_EQ(snapshot.load_imbalance_stddev, 0.0);
}

TEST_F(MetricsCollectorTest, NegativeElapsedTimeDoesNotThrowOrProduceNegativeThroughput) {
    MetricsCollector collector(allocator, executor, monitor);
    EXPECT_NO_THROW({
        const auto snapshot = collector.collect(-5.0);
        EXPECT_GE(snapshot.throughput_tasks_per_second, 0.0);
    });
}

TEST_F(MetricsCollectorTest, AverageCpuUtilizationReflectsEdgeUsage) {
    monitor->getEdgeNode("E01")->allocateResources(50.0, 100.0, 1.0);
    MetricsCollector collector(allocator, executor, monitor);
    const auto snapshot = collector.collect(1.0);
    EXPECT_GT(snapshot.average_cpu_utilization_percent, 0.0);
}

TEST_F(MetricsCollectorTest, MultipleCollectCallsAreIndependentAndConsistent) {
    MetricsCollector collector(allocator, executor, monitor);
    const auto first = collector.collect(2.0);
    const auto second = collector.collect(2.0);
    EXPECT_DOUBLE_EQ(first.average_cpu_utilization_percent, second.average_cpu_utilization_percent);
    EXPECT_DOUBLE_EQ(first.load_imbalance_stddev, second.load_imbalance_stddev);
}

TEST_F(MetricsCollectorTest, CollectorDoesNotMutateAnyUnderlyingComponentState) {
    MetricsCollector collector(allocator, executor, monitor);
    const uint64_t allocations_before = allocator->getTotalAllocations();
    const uint64_t executed_before = executor->getTotalTasksExecuted();

    collector.collect(1.0);
    collector.collectAsJson(1.0);

    EXPECT_EQ(allocator->getTotalAllocations(), allocations_before);
    EXPECT_EQ(executor->getTotalTasksExecuted(), executed_before);
}

TEST_F(MetricsCollectorTest, JsonAndStructSnapshotsAgreeOnEveryField) {
    MetricsCollector collector(allocator, executor, monitor);
    const auto snap = collector.collect(3.0);
    const json as_json = collector.collectAsJson(3.0);

    EXPECT_DOUBLE_EQ(as_json["average_waiting_time_ms"].get<double>(), snap.average_waiting_time_ms);
    EXPECT_DOUBLE_EQ(as_json["deadline_miss_rate_percent"].get<double>(), snap.deadline_miss_rate_percent);
    EXPECT_DOUBLE_EQ(as_json["average_cpu_utilization_percent"].get<double>(), snap.average_cpu_utilization_percent);
    EXPECT_DOUBLE_EQ(as_json["load_imbalance_stddev"].get<double>(), snap.load_imbalance_stddev);
}
