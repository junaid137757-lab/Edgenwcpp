#include <gtest/gtest.h>
#include "common/logger.h"

#include <fstream>
#include <sstream>
#include <cstdio>

// Logger is a process-wide singleton (MISRA deviation D6). Tests only
// observe externally visible effects (log file contents, no crashes)
// rather than trying to reset singleton state between cases.

TEST(LoggerTest, GetInstanceReturnsSameInstanceEveryTime) {
    Logger& first = Logger::getInstance();
    Logger& second = Logger::getInstance();
    EXPECT_EQ(&first, &second);
}

TEST(LoggerTest, AllSeverityHelpersRunWithoutThrowing) {
    Logger& logger = Logger::getInstance();
    logger.setMinLevel(Logger::Level::DEBUG);
    EXPECT_NO_THROW(logger.debug("LoggerTest", "debug message"));
    EXPECT_NO_THROW(logger.info("LoggerTest", "info message"));
    EXPECT_NO_THROW(logger.warn("LoggerTest", "warn message"));
    EXPECT_NO_THROW(logger.error("LoggerTest", "error message"));
}

TEST(LoggerTest, MessagesBelowMinLevelAreSuppressedWithoutError) {
    Logger& logger = Logger::getInstance();
    logger.setMinLevel(Logger::Level::ERROR);
    // DEBUG/INFO/WARN should all be silently dropped without throwing.
    EXPECT_NO_THROW(logger.debug("LoggerTest", "should be suppressed"));
    EXPECT_NO_THROW(logger.info("LoggerTest", "should be suppressed"));
    EXPECT_NO_THROW(logger.warn("LoggerTest", "should be suppressed"));
    logger.setMinLevel(Logger::Level::DEBUG);  // restore for other tests
}

TEST(LoggerTest, SetLogFileWritesEntriesToDisk) {
    const std::string path = "logger_test_output.log";
    std::remove(path.c_str());

    Logger& logger = Logger::getInstance();
    logger.setMinLevel(Logger::Level::DEBUG);
    logger.setLogFile(path);
    logger.info("LoggerTest", "written to file");

    std::ifstream file(path);
    ASSERT_TRUE(file.is_open());
    std::stringstream contents;
    contents << file.rdbuf();
    EXPECT_NE(contents.str().find("written to file"), std::string::npos);
    EXPECT_NE(contents.str().find("[INFO]"), std::string::npos);
    EXPECT_NE(contents.str().find("[LoggerTest]"), std::string::npos);

    file.close();
    std::remove(path.c_str());
}

TEST(LoggerTest, SetLogFileWithInvalidPathDoesNotThrow) {
    Logger& logger = Logger::getInstance();
    // A directory that does not exist: ofstream::open will simply fail
    // to open rather than throwing, and logging afterward must remain
    // safe (falls back to console-only output).
    EXPECT_NO_THROW(logger.setLogFile("/nonexistent_dir_xyz/should_fail.log"));
    EXPECT_NO_THROW(logger.info("LoggerTest", "still safe after failed file open"));
}

TEST(LoggerTest, ErrorAndWarnLevelsAreDistinctFromInfo) {
    // Exercises the ERROR/WARN branch (stderr) vs INFO/DEBUG branch
    // (stdout) inside Logger::log without asserting on stream contents,
    // since capturing std::cerr/std::cout reliably across platforms is
    // out of scope — the goal here is branch coverage without flakiness.
    Logger& logger = Logger::getInstance();
    logger.setMinLevel(Logger::Level::DEBUG);
    EXPECT_NO_THROW(logger.warn("LoggerTest", "goes to stderr path"));
    EXPECT_NO_THROW(logger.error("LoggerTest", "goes to stderr path"));
}
