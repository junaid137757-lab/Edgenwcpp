#ifndef TESTS_TEST_DB_HELPER_H
#define TESTS_TEST_DB_HELPER_H

#include "database/database_manager.h"

/**
 * DatabaseManager is a process-wide singleton (MISRA deviation D6), so
 * every test file that touches it — directly (test_database_manager.cpp)
 * or indirectly (test_task_executor.cpp, which calls into it from
 * TaskExecutor's execution path) — shares one connection for the whole
 * test binary. Calling initialize() is idempotent-safe to call more than
 * once per process here because each call re-opens the same in-memory
 * handle; guarding with isInitialized() just avoids redundant re-opens
 * and schema re-creation churn across test files.
 *
 * An in-memory database (":memory:") is used so tests never touch the
 * developer's real data/simulation.db and leave no file behind.
 */
inline void ensureTestDatabaseInitialized() {
    DatabaseManager& db = DatabaseManager::getInstance();
    if (!db.isInitialized()) {
        db.initialize(":memory:");
    }
}

#endif  // TESTS_TEST_DB_HELPER_H
