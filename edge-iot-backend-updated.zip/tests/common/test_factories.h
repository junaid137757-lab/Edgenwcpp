#ifndef TESTS_COMMON_TEST_FACTORIES_H
#define TESTS_COMMON_TEST_FACTORIES_H

// Shared object-builder helpers for integration/function tests, which
// (unlike the unit tests in tests/unit/) routinely need to wire up
// several real collaborators — EdgeNode, Task, TaskManager, etc. —
// rather than isolating just one class. Kept minimal and consistent
// with the equivalent private helpers already used across
// tests/unit/*.cpp so behavior/defaults match between tiers.

#include "edge/edge_node.h"
#include "task/task.h"

#include <memory>
#include <string>

namespace test_factories {

inline std::shared_ptr<EdgeNode> makeEdge(
    const std::string& id,
    double cpu_capacity = 100.0,
    double ram_mb = 16384.0,
    double bandwidth_mbps = 100.0,
    int64_t latency_ms = 15) {
    EdgeNode::ResourceCapacity cap;
    cap.cpu_percent = cpu_capacity;
    cap.ram_mb = ram_mb;
    cap.bandwidth_mbps = bandwidth_mbps;
    cap.latency_ms = latency_ms;
    return std::make_shared<EdgeNode>(id, cap);
}

inline Task::TaskRequirements makeRequirements(
    double cpu_percent = 10.0,
    double ram_mb = 50.0,
    double bandwidth_mbps = 1.0,
    int64_t deadline_ms = 5000,
    Task::TaskPriority priority = Task::TaskPriority::HIGH) {
    Task::TaskRequirements req;
    req.cpu_percent = cpu_percent;
    req.ram_mb = ram_mb;
    req.bandwidth_mbps = bandwidth_mbps;
    req.deadline_ms = deadline_ms;
    req.priority = priority;
    return req;
}

inline std::shared_ptr<Task> makeTask(
    const std::string& id,
    const std::string& device_id = "DEV1",
    const std::string& sensor_type = "temperature",
    Task::TaskPriority priority = Task::TaskPriority::HIGH) {
    return std::make_shared<Task>(
        id, device_id, sensor_type, makeRequirements(10.0, 50.0, 1.0, 5000, priority),
        json::object());
}

}  // namespace test_factories

#endif  // TESTS_COMMON_TEST_FACTORIES_H
