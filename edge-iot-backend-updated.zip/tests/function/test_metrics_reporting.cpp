// FUNCTION TESTS
//
// Verifies the functional promises of spec §17's named metrics
// (success rate, deadline miss rate, throughput, load imbalance) as
// black-box properties of MetricsCollector wired to REAL
// ResourceAllocator/TaskExecutor/ResourceMonitor instances, rather than
// MetricsCollector's internal contract in isolation (see
// tests/unit/test_metrics_collector.cpp for that).
#include <gtest/gtest.h>
#include "metrics/metrics_collector.h"
#include "scheduler/task_scheduler.h"
#include "common/test_factories.h"

#include <chrono>
#include <thread>

using test_factories::makeEdge;
using test_factories::makeTask;
using test_factories::makeRequirements;

namespace {

class MetricsReportingTest : public ::testing::Test {
protected:
    void SetUp() override {
        monitor = std::make_shared<ResourceMonitor>();
        allocator = std::make_shared<ResourceAllocator>(
            monitor, ResourceAllocator::AllocationStrategy::MULTI_CONSTRAINT);
        scheduler = std::make_shared<TaskScheduler>(TaskScheduler::SchedulingStrategy::FIFO);
        executor = std::make_shared<TaskExecutor>(scheduler);
    }

    void TearDown() override {
        if (executor) {
            executor->stop();
        }
    }

    bool waitUntilAllFinished(std::size_t expected_count, int max_iterations = 300) {
        for (int i = 0; i < max_iterations; ++i) {
            std::this_thread::sleep_for(std::chrono::milliseconds(10));
            if (executor->getTotalTasksExecuted() + executor->getTotalTasksFailed() >= expected_count) {
                return true;
            }
        }
        return false;
    }

    std::shared_ptr<ResourceMonitor> monitor;
    std::shared_ptr<ResourceAllocator> allocator;
    std::shared_ptr<TaskScheduler> scheduler;
    std::shared_ptr<TaskExecutor> executor;
};

}  // namespace

TEST_F(MetricsReportingTest, TaskSuccessRateIs100PercentWhenNothingMissesItsDeadline) {
    auto edge = makeEdge("E01");
    monitor->registerEdgeNode(edge);
    executor->registerEdgeNode(edge);
    executor->start();

    for (int i = 0; i < 3; ++i) {
        auto task = makeTask("T" + std::to_string(i), "DEV1", "temperature");
        ASSERT_TRUE(allocator->allocateTask(task).success);
        scheduler->scheduleTask(edge, task);
    }
    ASSERT_TRUE(waitUntilAllFinished(3U));

    MetricsCollector collector(allocator, executor, monitor);
    const auto snapshot = collector.collect(1.0);
    EXPECT_DOUBLE_EQ(snapshot.task_success_rate_percent, 100.0);
    EXPECT_DOUBLE_EQ(snapshot.deadline_miss_rate_percent, 0.0);
}

TEST_F(MetricsReportingTest, DeadlineMissRateReflectsMissedTasks) {
    auto edge = makeEdge("E01");
    monitor->registerEdgeNode(edge);
    executor->registerEdgeNode(edge);
    executor->start();

    // One achievable task, one with an impossible 1ms deadline.
    auto ok_task = makeTask("T_OK");
    ASSERT_TRUE(allocator->allocateTask(ok_task).success);
    scheduler->scheduleTask(edge, ok_task);

    Task::TaskRequirements late_req = makeRequirements(1.0, 10.0, 1.0, 1, Task::TaskPriority::HIGH);
    auto late_task = std::make_shared<Task>("T_LATE", "DEV1", "temperature", late_req, json::object());
    ASSERT_TRUE(allocator->allocateTask(late_task).success);
    scheduler->scheduleTask(edge, late_task);

    ASSERT_TRUE(waitUntilAllFinished(2U));

    MetricsCollector collector(allocator, executor, monitor);
    const auto snapshot = collector.collect(1.0);
    EXPECT_GT(snapshot.deadline_miss_rate_percent, 0.0);
    EXPECT_LT(snapshot.task_success_rate_percent, 100.0);
}

TEST_F(MetricsReportingTest, ThroughputScalesInverselyWithElapsedTime) {
    auto edge = makeEdge("E01");
    monitor->registerEdgeNode(edge);
    executor->registerEdgeNode(edge);
    executor->start();

    auto task = makeTask("T1");
    ASSERT_TRUE(allocator->allocateTask(task).success);
    scheduler->scheduleTask(edge, task);
    ASSERT_TRUE(waitUntilAllFinished(1U));

    MetricsCollector collector(allocator, executor, monitor);
    const auto fast_window = collector.collect(1.0);
    const auto slow_window = collector.collect(10.0);

    // Same completed-task count over a longer window means lower
    // throughput (tasks/second).
    EXPECT_GT(fast_window.throughput_tasks_per_second, slow_window.throughput_tasks_per_second);
}

TEST_F(MetricsReportingTest, LoadImbalanceIsZeroWithASingleEdgeNode) {
    // Standard deviation across exactly one data point is 0 by
    // definition — a degenerate but meaningful boundary case.
    monitor->registerEdgeNode(makeEdge("E01"));
    executor->registerEdgeNode(monitor->getEdgeNode("E01"));

    MetricsCollector collector(allocator, executor, monitor);
    const auto snapshot = collector.collect(1.0);
    EXPECT_DOUBLE_EQ(snapshot.load_imbalance_stddev, 0.0);
}

TEST_F(MetricsReportingTest, LoadImbalanceIsPositiveWhenOneNodeIsFarMoreLoadedThanAnother) {
    auto light = makeEdge("LIGHT", 100.0, 16384.0, 100.0, 10);
    auto heavy = makeEdge("HEAVY", 100.0, 16384.0, 100.0, 10);
    heavy->allocateResources(90.0, 14000.0, 90.0);  // heavily loaded
    monitor->registerEdgeNode(light);
    monitor->registerEdgeNode(heavy);
    executor->registerEdgeNode(light);
    executor->registerEdgeNode(heavy);

    MetricsCollector collector(allocator, executor, monitor);
    const auto snapshot = collector.collect(1.0);
    EXPECT_GT(snapshot.load_imbalance_stddev, 0.0);
}

TEST_F(MetricsReportingTest, MetricsAreAllZeroBeforeAnyTaskRunsOrAnyEdgeExists) {
    MetricsCollector collector(allocator, executor, monitor);
    const auto snapshot = collector.collect(1.0);

    EXPECT_DOUBLE_EQ(snapshot.average_latency_ms, 0.0);
    EXPECT_DOUBLE_EQ(snapshot.throughput_tasks_per_second, 0.0);
}

TEST_F(MetricsReportingTest, CollectAsJsonContainsAllSevenNamedMetrics) {
    MetricsCollector collector(allocator, executor, monitor);
    const json snapshot_json = collector.collectAsJson(1.0);

    for (const char* key : {"average_latency_ms", "average_waiting_time_ms",
                             "deadline_miss_rate_percent", "average_cpu_utilization_percent",
                             "load_imbalance_stddev", "throughput_tasks_per_second",
                             "task_success_rate_percent"}) {
        EXPECT_TRUE(snapshot_json.contains(key)) << "missing metric: " << key;
    }
}
