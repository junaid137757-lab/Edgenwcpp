// FUNCTION TESTS
//
// Verifies the functional promises of the Multi-Constraint allocator
// (spec §8-9) as a black box through ResourceAllocator + ResourceMonitor
// + EdgeNode together: capacity-aware selection, latency preference,
// infeasibility rejection, and weight-driven configurability — rather
// than any one class's internal contract (see
// tests/unit/test_resource_allocator.cpp for that).
#include <gtest/gtest.h>
#include "resource/resource_allocator.h"
#include "common/test_factories.h"

#include <map>
#include <string>

using test_factories::makeEdge;
using test_factories::makeTask;
using test_factories::makeRequirements;

namespace {

class AllocationBehaviorTest : public ::testing::Test {
protected:
    void SetUp() override {
        monitor = std::make_shared<ResourceMonitor>();
        allocator = std::make_shared<ResourceAllocator>(
            monitor, ResourceAllocator::AllocationStrategy::MULTI_CONSTRAINT);
    }

    std::shared_ptr<ResourceMonitor> monitor;
    std::shared_ptr<ResourceAllocator> allocator;
};

}  // namespace

TEST_F(AllocationBehaviorTest, PicksTheLessLoadedOfTwoEquallyCapableEdges) {
    auto busy = makeEdge("BUSY", 100.0, 16384.0, 100.0, 20);
    auto idle = makeEdge("IDLE", 100.0, 16384.0, 100.0, 20);
    busy->allocateResources(80.0, 12000.0, 80.0);  // BUSY is nearly saturated
    monitor->registerEdgeNode(busy);
    monitor->registerEdgeNode(idle);

    auto task = makeTask("T1");
    const auto result = allocator->allocateTask(task);

    ASSERT_TRUE(result.success);
    EXPECT_EQ(result.edge_id, "IDLE");
}

TEST_F(AllocationBehaviorTest, PrefersLowerLatencyWhenLoadIsOtherwiseEqual) {
    monitor->registerEdgeNode(makeEdge("FAR", 100.0, 16384.0, 100.0, 90));
    monitor->registerEdgeNode(makeEdge("NEAR", 100.0, 16384.0, 100.0, 5));

    auto task = makeTask("T1");
    const auto result = allocator->allocateTask(task);

    ASSERT_TRUE(result.success);
    EXPECT_EQ(result.edge_id, "NEAR");
}

TEST_F(AllocationBehaviorTest, RejectsAnEdgeThatCannotSatisfyCpuRequirement) {
    monitor->registerEdgeNode(makeEdge("TINY", 5.0, 16384.0, 100.0, 5));  // only 5% CPU capacity
    auto demanding_task = makeTask("T1");  // default requirement: 10% CPU

    const auto result = allocator->allocateTask(demanding_task);
    EXPECT_FALSE(result.success);
    ASSERT_EQ(result.candidates.size(), 1U);
    EXPECT_FALSE(result.candidates[0].feasible);
}

TEST_F(AllocationBehaviorTest, RejectsAnEdgeThatCannotSatisfyRamRequirement) {
    monitor->registerEdgeNode(makeEdge("LOW_RAM", 100.0, 10.0, 100.0, 5));  // only 10MB RAM
    auto task = makeTask("T1");  // default requirement: 50MB RAM

    const auto result = allocator->allocateTask(task);
    EXPECT_FALSE(result.success);
}

TEST_F(AllocationBehaviorTest, SkipsInfeasibleEdgeAndPicksFeasibleOne) {
    monitor->registerEdgeNode(makeEdge("TOO_SMALL", 5.0, 16384.0, 100.0, 5));
    monitor->registerEdgeNode(makeEdge("BIG_ENOUGH", 100.0, 16384.0, 100.0, 5));

    auto task = makeTask("T1");
    const auto result = allocator->allocateTask(task);

    ASSERT_TRUE(result.success);
    EXPECT_EQ(result.edge_id, "BIG_ENOUGH");
    ASSERT_EQ(result.candidates.size(), 2U);
}

TEST_F(AllocationBehaviorTest, FailsCleanlyWithNoRegisteredEdgeNodes) {
    auto task = makeTask("T1");
    const auto result = allocator->allocateTask(task);
    EXPECT_FALSE(result.success);
    EXPECT_TRUE(result.candidates.empty());
}

TEST_F(AllocationBehaviorTest, FailsCleanlyWhenAllRegisteredNodesAreUnavailable) {
    monitor->registerEdgeNode(makeEdge("E01"));
    monitor->simulateNodeFailure("E01");

    auto task = makeTask("T1");
    const auto result = allocator->allocateTask(task);
    EXPECT_FALSE(result.success);
}

TEST_F(AllocationBehaviorTest, SuccessfulAllocationReservesCapacityOnTheEdge) {
    auto edge = makeEdge("E01", 100.0, 16384.0, 100.0, 5);
    monitor->registerEdgeNode(edge);

    auto task = makeTask("T1");  // 10% CPU, 50MB RAM, 1 Mbps by default
    ASSERT_TRUE(allocator->allocateTask(task).success);

    EXPECT_DOUBLE_EQ(edge->getAvailableCpuPercent(), 90.0);
    EXPECT_DOUBLE_EQ(edge->getAvailableRamMb(), 16334.0);
}

TEST_F(AllocationBehaviorTest, CustomWeightsCanMakeLatencyTheDecidingFactor) {
    // Zero out every weight except latency: whichever edge has lower
    // latency must win regardless of its (worse) load state.
    ResourceAllocator::AllocationWeights latency_only;
    latency_only.cpu_weight = 0.0;
    latency_only.ram_weight = 0.0;
    latency_only.bandwidth_weight = 0.0;
    latency_only.latency_weight = 1.0;
    latency_only.queue_weight = 0.0;
    latency_only.priority_weight = 0.0;
    allocator->setAllocationWeights(latency_only);

    auto low_latency_but_loaded = makeEdge("LOW_LAT", 100.0, 16384.0, 100.0, 1);
    low_latency_but_loaded->allocateResources(85.0, 15000.0, 90.0);
    auto high_latency_idle = makeEdge("HIGH_LAT", 100.0, 16384.0, 100.0, 95);
    monitor->registerEdgeNode(low_latency_but_loaded);
    monitor->registerEdgeNode(high_latency_idle);

    auto task = makeTask("T1");
    const auto result = allocator->allocateTask(task);

    ASSERT_TRUE(result.success);
    EXPECT_EQ(result.edge_id, "LOW_LAT");
}

TEST_F(AllocationBehaviorTest, AllocateTaskWithRetryStopsImmediatelyWithNoEdges) {
    auto task = makeTask("T1");
    const auto result = allocator->allocateTaskWithRetry(task, 5U, std::chrono::milliseconds(1));
    EXPECT_FALSE(result.success);
    // With zero edge nodes registered at all, the retry loop's own
    // "no edges to wait for" short-circuit should fire on the first pass
    // rather than sleeping through every one of the 5 retries.
}

TEST_F(AllocationBehaviorTest, RepeatedAllocationDistributesAcrossEquallyCapableEdges) {
    // The recent-allocation-history component of the score should, over
    // several allocations of otherwise-identical tasks to otherwise-
    // identical edges, favor the less-recently-used node rather than
    // pinning every task onto the very first candidate evaluated.
    monitor->registerEdgeNode(makeEdge("E01", 100.0, 16384.0, 100.0, 10));
    monitor->registerEdgeNode(makeEdge("E02", 100.0, 16384.0, 100.0, 10));

    std::map<std::string, int> selection_counts;
    for (int i = 0; i < 10; ++i) {
        auto task = makeTask("T" + std::to_string(i));
        const auto result = allocator->allocateTask(task);
        if (result.success) {
            ++selection_counts[result.edge_id];
        }
    }

    // Both edges should have received at least one task; a purely
    // deterministic "always pick candidate #1" implementation would
    // give one of them zero.
    EXPECT_GT(selection_counts["E01"], 0);
    EXPECT_GT(selection_counts["E02"], 0);
}

TEST_F(AllocationBehaviorTest, TotalAndSuccessfulAllocationCountersTrackOutcomes) {
    monitor->registerEdgeNode(makeEdge("E01", 5.0, 5.0, 5.0, 5));  // too small for anything
    auto task = makeTask("T1");
    allocator->allocateTask(task);

    EXPECT_EQ(allocator->getTotalAllocations(), 1U);
    EXPECT_EQ(allocator->getSuccessfulAllocations(), 0U);
    EXPECT_EQ(allocator->getFailedAllocations(), 1U);
}
