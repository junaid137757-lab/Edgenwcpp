// FUNCTION TESTS
//
// Where tests/unit/test_task_scheduler.cpp checks TaskScheduler's
// class-level contract in isolation, these verify the functional
// requirement from spec §13 end to end: "given a mix of tasks with
// different [priorities/deadlines/arrival order], each scheduling
// strategy must select them in ITS documented order" — treating
// TaskScheduler + EdgeNode together as one black box addressed only
// through scheduleTask()/getNextTask().
#include <gtest/gtest.h>
#include "scheduler/task_scheduler.h"
#include "common/test_factories.h"

#include <thread>
#include <chrono>

using test_factories::makeEdge;

namespace {

std::shared_ptr<Task> taskWithPriority(const std::string& id, Task::TaskPriority priority) {
    return test_factories::makeTask(id, "DEV1", "temperature", priority);
}

std::shared_ptr<Task> taskWithDeadline(const std::string& id, int64_t deadline_ms) {
    Task::TaskRequirements req = test_factories::makeRequirements();
    req.deadline_ms = deadline_ms;
    return std::make_shared<Task>(id, "DEV1", "temperature", req, json::object());
}

}  // namespace

TEST(SchedulingBehaviorTest, FifoPreservesArrivalOrderAcrossPriorities) {
    TaskScheduler scheduler(TaskScheduler::SchedulingStrategy::FIFO);
    auto edge = makeEdge("E01");

    auto low_first = taskWithPriority("T1", Task::TaskPriority::LOW);
    scheduler.scheduleTask(edge, low_first);
    auto critical_second = taskWithPriority("T2", Task::TaskPriority::CRITICAL);
    scheduler.scheduleTask(edge, critical_second);

    // FIFO must ignore priority entirely: T1 arrived first.
    EXPECT_EQ(scheduler.getNextTask(edge)->getTaskId(), "T1");
    EXPECT_EQ(scheduler.getNextTask(edge)->getTaskId(), "T2");
}

TEST(SchedulingBehaviorTest, PriorityBasedSelectsCriticalOverAllOthers) {
    TaskScheduler scheduler(TaskScheduler::SchedulingStrategy::PRIORITY_BASED);
    auto edge = makeEdge("E01");

    scheduler.scheduleTask(edge, taskWithPriority("T_LOW", Task::TaskPriority::LOW));
    scheduler.scheduleTask(edge, taskWithPriority("T_MED", Task::TaskPriority::MEDIUM));
    scheduler.scheduleTask(edge, taskWithPriority("T_HIGH", Task::TaskPriority::HIGH));
    scheduler.scheduleTask(edge, taskWithPriority("T_CRIT", Task::TaskPriority::CRITICAL));

    EXPECT_EQ(scheduler.getNextTask(edge)->getTaskId(), "T_CRIT");
    EXPECT_EQ(scheduler.getNextTask(edge)->getTaskId(), "T_HIGH");
    EXPECT_EQ(scheduler.getNextTask(edge)->getTaskId(), "T_MED");
    EXPECT_EQ(scheduler.getNextTask(edge)->getTaskId(), "T_LOW");
}

TEST(SchedulingBehaviorTest, PriorityBasedMatchesSpecWorkedExample) {
    // Spec §13's own worked example:
    // T103(CRITICAL) -> T101(HIGH) -> T104(MEDIUM) -> T102(LOW)
    TaskScheduler scheduler(TaskScheduler::SchedulingStrategy::PRIORITY_BASED);
    auto edge = makeEdge("E01");

    scheduler.scheduleTask(edge, taskWithPriority("T101", Task::TaskPriority::HIGH));
    scheduler.scheduleTask(edge, taskWithPriority("T102", Task::TaskPriority::LOW));
    scheduler.scheduleTask(edge, taskWithPriority("T103", Task::TaskPriority::CRITICAL));
    scheduler.scheduleTask(edge, taskWithPriority("T104", Task::TaskPriority::MEDIUM));

    std::vector<std::string> order;
    while (edge->hasTasksInQueue()) {
        order.push_back(scheduler.getNextTask(edge)->getTaskId());
    }
    const std::vector<std::string> expected = {"T103", "T101", "T104", "T102"};
    EXPECT_EQ(order, expected);
}

TEST(SchedulingBehaviorTest, EarliestDeadlineFirstSelectsSoonestDeadline) {
    TaskScheduler scheduler(TaskScheduler::SchedulingStrategy::EARLIEST_DEADLINE_FIRST);
    auto edge = makeEdge("E01");

    scheduler.scheduleTask(edge, taskWithDeadline("T_FAR", 10000));
    scheduler.scheduleTask(edge, taskWithDeadline("T_SOON", 100));
    scheduler.scheduleTask(edge, taskWithDeadline("T_MID", 1000));

    EXPECT_EQ(scheduler.getNextTask(edge)->getTaskId(), "T_SOON");
    EXPECT_EQ(scheduler.getNextTask(edge)->getTaskId(), "T_MID");
    EXPECT_EQ(scheduler.getNextTask(edge)->getTaskId(), "T_FAR");
}

TEST(SchedulingBehaviorTest, EdfIgnoresPriorityWhenDeadlinesDiffer) {
    TaskScheduler scheduler(TaskScheduler::SchedulingStrategy::EARLIEST_DEADLINE_FIRST);
    auto edge = makeEdge("E01");

    // A LOW priority task with an imminent deadline must still beat a
    // CRITICAL task with a distant one — EDF cares only about time.
    Task::TaskRequirements urgent_low_req = test_factories::makeRequirements(
        10.0, 50.0, 1.0, 50, Task::TaskPriority::LOW);
    auto urgent_low = std::make_shared<Task>(
        "T_URGENT_LOW", "DEV1", "temperature", urgent_low_req, json::object());
    scheduler.scheduleTask(edge, urgent_low);

    Task::TaskRequirements relaxed_critical_req = test_factories::makeRequirements(
        10.0, 50.0, 1.0, 100000, Task::TaskPriority::CRITICAL);
    auto relaxed_critical = std::make_shared<Task>(
        "T_RELAXED_CRITICAL", "DEV1", "temperature", relaxed_critical_req, json::object());
    scheduler.scheduleTask(edge, relaxed_critical);

    EXPECT_EQ(scheduler.getNextTask(edge)->getTaskId(), "T_URGENT_LOW");
}

TEST(SchedulingBehaviorTest, RoundRobinDrainsInEnqueueOrder) {
    TaskScheduler scheduler(TaskScheduler::SchedulingStrategy::ROUND_ROBIN_TIME_SLICE);
    auto edge = makeEdge("E01");

    scheduler.scheduleTask(edge, taskWithPriority("T1", Task::TaskPriority::LOW));
    scheduler.scheduleTask(edge, taskWithPriority("T2", Task::TaskPriority::HIGH));
    scheduler.scheduleTask(edge, taskWithPriority("T3", Task::TaskPriority::MEDIUM));

    EXPECT_EQ(scheduler.getNextTask(edge)->getTaskId(), "T1");
    EXPECT_EQ(scheduler.getNextTask(edge)->getTaskId(), "T2");
    EXPECT_EQ(scheduler.getNextTask(edge)->getTaskId(), "T3");
}

TEST(SchedulingBehaviorTest, SwitchingStrategyMidRunAffectsSubsequentSelectionOnly) {
    TaskScheduler scheduler(TaskScheduler::SchedulingStrategy::FIFO);
    auto edge = makeEdge("E01");

    scheduler.scheduleTask(edge, taskWithPriority("T_FIRST", Task::TaskPriority::LOW));
    scheduler.scheduleTask(edge, taskWithPriority("T_CRIT", Task::TaskPriority::CRITICAL));

    scheduler.setStrategy(TaskScheduler::SchedulingStrategy::PRIORITY_BASED);
    // getNextTask() re-evaluates the whole remaining queue under the
    // NEW strategy at call time, since TaskScheduler holds no
    // pre-sorted state of its own — it's stateless over EdgeNode's queue.
    EXPECT_EQ(scheduler.getNextTask(edge)->getTaskId(), "T_CRIT");
}

TEST(SchedulingBehaviorTest, TotalTasksScheduledCountsAcrossMultipleEdges) {
    TaskScheduler scheduler(TaskScheduler::SchedulingStrategy::FIFO);
    auto edge1 = makeEdge("E01");
    auto edge2 = makeEdge("E02");

    scheduler.scheduleTask(edge1, taskWithPriority("T1", Task::TaskPriority::LOW));
    scheduler.scheduleTask(edge2, taskWithPriority("T2", Task::TaskPriority::LOW));
    scheduler.scheduleTask(edge1, taskWithPriority("T3", Task::TaskPriority::LOW));

    EXPECT_EQ(scheduler.getTotalTasksScheduled(), 3U);
}

TEST(SchedulingBehaviorTest, EmptyQueueAcrossAllStrategiesReturnsNullptr) {
    auto edge = makeEdge("E01");
    for (auto strategy : {TaskScheduler::SchedulingStrategy::FIFO,
                           TaskScheduler::SchedulingStrategy::PRIORITY_BASED,
                           TaskScheduler::SchedulingStrategy::EARLIEST_DEADLINE_FIRST,
                           TaskScheduler::SchedulingStrategy::ROUND_ROBIN_TIME_SLICE}) {
        TaskScheduler scheduler(strategy);
        EXPECT_EQ(scheduler.getNextTask(edge), nullptr);
    }
}

TEST(SchedulingBehaviorTest, GetNextTaskLeavesRemainingTasksInOriginalRelativeOrder) {
    TaskScheduler scheduler(TaskScheduler::SchedulingStrategy::PRIORITY_BASED);
    auto edge = makeEdge("E01");

    scheduler.scheduleTask(edge, taskWithPriority("T_CRIT", Task::TaskPriority::CRITICAL));
    scheduler.scheduleTask(edge, taskWithPriority("T_LOW_A", Task::TaskPriority::LOW));
    scheduler.scheduleTask(edge, taskWithPriority("T_LOW_B", Task::TaskPriority::LOW));

    scheduler.getNextTask(edge);  // pulls T_CRIT, restores the two LOW tasks

    EXPECT_EQ(scheduler.getNextTask(edge)->getTaskId(), "T_LOW_A");
    EXPECT_EQ(scheduler.getNextTask(edge)->getTaskId(), "T_LOW_B");
}
