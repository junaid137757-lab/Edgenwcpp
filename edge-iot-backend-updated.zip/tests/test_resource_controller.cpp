#include <gtest/gtest.h>
#include "resource/resource_controller.h"

#include <thread>
#include <chrono>

namespace {

std::shared_ptr<EdgeNode> makeEdge(const std::string& id) {
    EdgeNode::ResourceCapacity cap;
    cap.cpu_percent = 100.0;
    cap.ram_mb = 16384.0;
    cap.bandwidth_mbps = 100.0;
    cap.latency_ms = 10;
    return std::make_shared<EdgeNode>(id, cap);
}

std::shared_ptr<Task> makeTask(const std::string& id) {
    Task::TaskRequirements req;
    req.cpu_percent = 5.0;
    req.ram_mb = 20.0;
    req.bandwidth_mbps = 1.0;
    req.deadline_ms = 5000;
    req.priority = Task::TaskPriority::HIGH;
    return std::make_shared<Task>(id, "DEV1", "temperature", req, json::object());
}

class ResourceControllerTest : public ::testing::Test {
protected:
    void SetUp() override {
        task_manager = std::make_shared<TaskManager>();
        resource_monitor = std::make_shared<ResourceMonitor>();
        resource_monitor->registerEdgeNode(makeEdge("E01"));
        allocator = std::make_shared<ResourceAllocator>(
            resource_monitor, ResourceAllocator::AllocationStrategy::MULTI_CONSTRAINT);
        controller = std::make_unique<ResourceController>(task_manager, resource_monitor, allocator);
    }

    void TearDown() override {
        // Ensure any started controller thread is always joined, even
        // on test failure, to avoid crashing the whole test binary.
        if (controller) {
            controller->stop();
        }
    }

    std::shared_ptr<TaskManager> task_manager;
    std::shared_ptr<ResourceMonitor> resource_monitor;
    std::shared_ptr<ResourceAllocator> allocator;
    std::unique_ptr<ResourceController> controller;
};

}  // namespace

TEST_F(ResourceControllerTest, StartsNotRunningWithZeroedStatistics) {
    EXPECT_FALSE(controller->isRunning());
    EXPECT_EQ(controller->getTotalTasksAllocated(), 0U);
    EXPECT_EQ(controller->getTotalAllocationFailures(), 0U);
    EXPECT_EQ(controller->getTotalReallocations(), 0U);
}

TEST_F(ResourceControllerTest, StartSetsRunningAndStopClearsIt) {
    controller->start();
    EXPECT_TRUE(controller->isRunning());
    controller->stop();
    EXPECT_FALSE(controller->isRunning());
}

TEST_F(ResourceControllerTest, StartingTwiceIsANoOp) {
    controller->start();
    EXPECT_NO_THROW(controller->start());  // second start() should just return early
    EXPECT_TRUE(controller->isRunning());
}

TEST_F(ResourceControllerTest, StoppingWithoutStartingIsSafe) {
    EXPECT_NO_THROW(controller->stop());
    EXPECT_FALSE(controller->isRunning());
}

TEST_F(ResourceControllerTest, AllocateTaskNowSucceedsOnAvailableEdge) {
    auto task = makeTask("T1");
    const auto result = controller->allocateTaskNow(task);
    EXPECT_TRUE(result.success);
    EXPECT_EQ(controller->getTotalTasksAllocated(), 1U);
    EXPECT_EQ(controller->getTotalAllocationFailures(), 0U);
}

TEST_F(ResourceControllerTest, AllocateTaskNowFailsWhenNoEdgesAvailable) {
    resource_monitor->simulateNodeFailure("E01");
    auto task = makeTask("T1");
    const auto result = controller->allocateTaskNow(task);
    EXPECT_FALSE(result.success);
    EXPECT_EQ(controller->getTotalAllocationFailures(), 1U);
}

TEST_F(ResourceControllerTest, TaskManagerCreationCallbackFeedsAllocation) {
    // The constructor wires TaskManager's creation callback straight
    // into the controller's queue (onTaskCreated -> enqueueTask).
    task_manager->createTaskFromSensorData("DEV1", "temperature", json::object());
    EXPECT_TRUE(task_manager->hasTasksInQueue());
}

TEST_F(ResourceControllerTest, ProcessingLoopDrainsQueuedTasksWhileRunning) {
    task_manager->createTaskFromSensorData("DEV1", "temperature", json::object());
    controller->start();

    bool drained = false;
    for (int i = 0; i < 50 && !drained; ++i) {
        std::this_thread::sleep_for(std::chrono::milliseconds(20));
        drained = !task_manager->hasTasksInQueue();
    }
    controller->stop();

    EXPECT_TRUE(drained);
    EXPECT_GE(controller->getTotalTasksAllocated(), 1U);
}

TEST_F(ResourceControllerTest, NodeFailureCallbackTriggersReallocationOfQueuedTasks) {
    // Put a task directly on E01's queue (as if it had already been
    // allocated there), then fail the node and confirm the task is
    // pulled off and reallocated (Spec §10).
    auto edge = resource_monitor->getEdgeNode("E01");
    auto task = makeTask("T_STUCK");
    task->setAssignedEdgeId("E01");
    edge->enqueueTask(task);

    resource_monitor->registerEdgeNode(makeEdge("E02"));  // somewhere to reallocate to

    resource_monitor->simulateNodeFailure("E01");  // fires status callback -> handleNodeFailure

    EXPECT_EQ(controller->getTotalReallocations(), 1U);
    EXPECT_EQ(task->getStatus(), Task::TaskStatus::REALLOCATED);
    EXPECT_FALSE(edge->hasTasksInQueue());
}

TEST_F(ResourceControllerTest, ReallocateTasksFromUnknownNodeIsNoOp) {
    EXPECT_NO_THROW(controller->reallocateTasksFromFailedNode("GHOST"));
    EXPECT_EQ(controller->getTotalReallocations(), 0U);
}

TEST_F(ResourceControllerTest, ReallocateWithNoOtherAvailableEdgeCountsAsFailure) {
    auto edge = resource_monitor->getEdgeNode("E01");
    auto task = makeTask("T_STUCK");
    task->setAssignedEdgeId("E01");
    edge->enqueueTask(task);

    // No other edge nodes registered, so reallocation cannot succeed.
    resource_monitor->simulateNodeFailure("E01");

    EXPECT_EQ(controller->getTotalReallocations(), 0U);
    EXPECT_GE(controller->getTotalAllocationFailures(), 1U);
}

TEST_F(ResourceControllerTest, SetAllocationWeightsDoesNotThrow) {
    ResourceAllocator::AllocationWeights weights;
    weights.cpu_weight = 0.5;
    EXPECT_NO_THROW(controller->setAllocationWeights(weights));
}

TEST_F(ResourceControllerTest, SetAllocationStrategyDoesNotThrow) {
    EXPECT_NO_THROW(controller->setAllocationStrategy(
        ResourceAllocator::AllocationStrategy::MULTI_CONSTRAINT));
}
