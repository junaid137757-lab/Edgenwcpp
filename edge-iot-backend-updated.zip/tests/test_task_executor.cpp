#include <gtest/gtest.h>
#include "executor/task_executor.h"
#include "scheduler/task_scheduler.h"
#include "test_db_helper.h"

#include <chrono>
#include <thread>

namespace {

std::shared_ptr<EdgeNode> makeEdge(const std::string& id) {
    EdgeNode::ResourceCapacity cap;
    cap.cpu_percent = 100.0;
    cap.ram_mb = 16384.0;
    cap.bandwidth_mbps = 100.0;
    cap.latency_ms = 25;
    return std::make_shared<EdgeNode>(id, cap);
}

std::shared_ptr<Task> makeFastTask(const std::string& id, int64_t deadline_ms = 5000) {
    // Small cpu_percent keeps TaskExecutor::estimateExecutionTime's
    // (5ms base + 0.5*cpu) formula fast, so tests complete quickly.
    Task::TaskRequirements req;
    req.cpu_percent = 1.0;
    req.ram_mb = 10.0;
    req.bandwidth_mbps = 1.0;
    req.deadline_ms = deadline_ms;
    req.priority = Task::TaskPriority::HIGH;
    return std::make_shared<Task>(id, "DEV1", "temperature", req, json::object());
}

class TaskExecutorTest : public ::testing::Test {
protected:
    void SetUp() override {
        ensureTestDatabaseInitialized();
        scheduler = std::make_shared<TaskScheduler>(TaskScheduler::SchedulingStrategy::FIFO);
        executor = std::make_unique<TaskExecutor>(scheduler);
    }

    void TearDown() override {
        if (executor) {
            executor->stop();
        }
    }

    std::shared_ptr<TaskScheduler> scheduler;
    std::unique_ptr<TaskExecutor> executor;
};

}  // namespace

TEST_F(TaskExecutorTest, StartsNotRunningWithZeroedStatistics) {
    EXPECT_FALSE(executor->isRunning());
    EXPECT_EQ(executor->getTotalTasksExecuted(), 0U);
    EXPECT_EQ(executor->getTotalTasksFailed(), 0U);
    EXPECT_DOUBLE_EQ(executor->getAverageExecutionTimeMs(), 0.0);
    EXPECT_DOUBLE_EQ(executor->getAverageWaitingTimeMs(), 0.0);
    EXPECT_DOUBLE_EQ(executor->getAverageLatency(), 0.0);
}

TEST_F(TaskExecutorTest, RegisterAndUnregisterEdgeNodeDoesNotThrow) {
    auto edge = makeEdge("E01");
    EXPECT_NO_THROW(executor->registerEdgeNode(edge));
    EXPECT_NO_THROW(executor->unregisterEdgeNode("E01"));
    EXPECT_NO_THROW(executor->unregisterEdgeNode("NEVER_REGISTERED"));
}

TEST_F(TaskExecutorTest, RegisteringNullEdgeNodeIsSafelyIgnored) {
    EXPECT_NO_THROW(executor->registerEdgeNode(nullptr));
}

TEST_F(TaskExecutorTest, AverageLatencyReflectsRegisteredEdges) {
    executor->registerEdgeNode(makeEdge("E01"));  // latency 25ms
    EXPECT_DOUBLE_EQ(executor->getAverageLatency(), 25.0);
}

TEST_F(TaskExecutorTest, StartAndStopToggleRunningState) {
    executor->registerEdgeNode(makeEdge("E01"));
    executor->start();
    EXPECT_TRUE(executor->isRunning());
    executor->stop();
    EXPECT_FALSE(executor->isRunning());
}

TEST_F(TaskExecutorTest, StartingTwiceIsANoOp) {
    executor->registerEdgeNode(makeEdge("E01"));
    executor->start();
    EXPECT_NO_THROW(executor->start());
    EXPECT_TRUE(executor->isRunning());
}

TEST_F(TaskExecutorTest, StoppingWithoutStartingIsSafe) {
    EXPECT_NO_THROW(executor->stop());
}

TEST_F(TaskExecutorTest, ExecutesScheduledTaskToCompletion) {
    auto edge = makeEdge("E01");
    executor->registerEdgeNode(edge);
    scheduler->scheduleTask(edge, makeFastTask("T1"));

    executor->start();

    // The task may already have been dequeued by the worker thread by
    // the time we get here; poll on executor-level statistics instead
    // of a specific Task object to avoid a race.
    bool completed = false;
    for (int i = 0; i < 200 && !completed; ++i) {
        std::this_thread::sleep_for(std::chrono::milliseconds(10));
        completed = (executor->getTotalTasksExecuted() + executor->getTotalTasksFailed()) >= 1U;
    }
    executor->stop();

    EXPECT_TRUE(completed);
}

TEST_F(TaskExecutorTest, DeadlineMissedTaskIsCountedAsFailed) {
    auto edge = makeEdge("E01");
    executor->registerEdgeNode(edge);
    // A near-zero deadline guarantees isDeadlineExceeded() is true by
    // the time simulateTaskExecution checks it.
    scheduler->scheduleTask(edge, makeFastTask("T_LATE", 1));

    executor->start();
    bool finished = false;
    for (int i = 0; i < 200 && !finished; ++i) {
        std::this_thread::sleep_for(std::chrono::milliseconds(10));
        finished = (executor->getTotalTasksExecuted() + executor->getTotalTasksFailed()) >= 1U;
    }
    executor->stop();

    ASSERT_TRUE(finished);
    EXPECT_EQ(executor->getTotalTasksFailed(), 1U);
    EXPECT_EQ(executor->getTotalTasksExecuted(), 0U);
}

TEST_F(TaskExecutorTest, WaitForRunningReturnsTrueOnceTaskStarts) {
    auto edge = makeEdge("E01");
    executor->registerEdgeNode(edge);
    auto task = makeFastTask("T_WAIT");
    scheduler->scheduleTask(edge, task);

    executor->start();
    const bool started = executor->waitForRunning(task, std::chrono::milliseconds(500));
    executor->stop();

    EXPECT_TRUE(started);
}

TEST_F(TaskExecutorTest, WaitForRunningWithNullTaskReturnsFalse) {
    EXPECT_FALSE(executor->waitForRunning(nullptr, std::chrono::milliseconds(10)));
}

TEST_F(TaskExecutorTest, WaitForCompletionReturnsTrueAfterExecution) {
    auto edge = makeEdge("E01");
    executor->registerEdgeNode(edge);
    auto task = makeFastTask("T_COMPLETE");
    scheduler->scheduleTask(edge, task);

    executor->start();
    const bool completed = executor->waitForCompletion(task, std::chrono::milliseconds(2000));
    executor->stop();

    EXPECT_TRUE(completed);
}

TEST_F(TaskExecutorTest, WaitForCompletionWithNullTaskReturnsFalse) {
    EXPECT_FALSE(executor->waitForCompletion(nullptr, std::chrono::milliseconds(10)));
}

TEST_F(TaskExecutorTest, WaitForCompletionTimesOutWhenNothingIsRunning) {
    auto task = makeFastTask("T_NEVER_RUN");
    // Never registered/scheduled anywhere, and the executor is never
    // started, so this must time out rather than hang or throw.
    EXPECT_FALSE(executor->waitForCompletion(task, std::chrono::milliseconds(30)));
}

TEST_F(TaskExecutorTest, AverageExecutionTimeIsPositiveAfterCompletedTask) {
    auto edge = makeEdge("E01");
    executor->registerEdgeNode(edge);
    scheduler->scheduleTask(edge, makeFastTask("T_TIMED"));

    executor->start();
    bool finished = false;
    for (int i = 0; i < 200 && !finished; ++i) {
        std::this_thread::sleep_for(std::chrono::milliseconds(10));
        finished = (executor->getTotalTasksExecuted() + executor->getTotalTasksFailed()) >= 1U;
    }
    executor->stop();

    ASSERT_TRUE(finished);
    EXPECT_GT(executor->getAverageExecutionTimeMs(), 0.0);
    EXPECT_GT(executor->getAverageWaitingTimeMs(), -1.0);  // non-negative, may legitimately be 0
}
