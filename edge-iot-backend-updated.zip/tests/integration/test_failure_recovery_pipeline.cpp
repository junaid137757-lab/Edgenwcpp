// INTEGRATION TESTS: node-failure recovery across ResourceController,
// ResourceMonitor, ResourceAllocator, TaskScheduler, and TaskExecutor
// together — spec §10's "Find tasks assigned to failed node ->
// Reallocation -> another node -> execution continues" flow, verified
// with a REAL executor thread actually draining the reallocated task,
// not just checked at the allocation-bookkeeping level (that narrower
// check already lives in tests/unit/test_resource_controller.cpp).
#include <gtest/gtest.h>
#include "resource/resource_controller.h"
#include "scheduler/task_scheduler.h"
#include "executor/task_executor.h"
#include "common/test_db_helper.h"
#include "common/test_factories.h"

#include <chrono>
#include <thread>

using test_factories::makeEdge;
using test_factories::makeTask;

namespace {

class FailureRecoveryIntegrationTest : public ::testing::Test {
protected:
    void SetUp() override {
        ensureTestDatabaseInitialized();

        monitor = std::make_shared<ResourceMonitor>();
        task_manager = std::make_shared<TaskManager>();
        allocator = std::make_shared<ResourceAllocator>(
            monitor, ResourceAllocator::AllocationStrategy::MULTI_CONSTRAINT);
        scheduler = std::make_shared<TaskScheduler>(TaskScheduler::SchedulingStrategy::FIFO);
        executor = std::make_shared<TaskExecutor>(scheduler);
        controller = std::make_unique<ResourceController>(task_manager, monitor, allocator, scheduler);
    }

    void TearDown() override {
        if (controller) {
            controller->stop();
        }
        if (executor) {
            executor->stop();
        }
    }

    std::shared_ptr<ResourceMonitor> monitor;
    std::shared_ptr<TaskManager> task_manager;
    std::shared_ptr<ResourceAllocator> allocator;
    std::shared_ptr<TaskScheduler> scheduler;
    std::shared_ptr<TaskExecutor> executor;
    std::unique_ptr<ResourceController> controller;
};

}  // namespace

TEST_F(FailureRecoveryIntegrationTest, TaskReallocatedFromFailedNodeStillReachesExecution) {
    monitor->registerEdgeNode(makeEdge("E01"));
    monitor->registerEdgeNode(makeEdge("E02"));
    executor->registerEdgeNode(monitor->getEdgeNode("E01"));
    executor->registerEdgeNode(monitor->getEdgeNode("E02"));

    // Place a task directly into E01's queue, as if the allocator had
    // already put it there, then fail E01.
    auto task = makeTask("T_FAILOVER");
    task->setAssignedEdgeId("E01");
    monitor->getEdgeNode("E01")->enqueueTask(task);

    executor->start();
    monitor->simulateNodeFailure("E01");  // triggers ResourceController's reallocation

    bool finished = false;
    for (int i = 0; i < 200 && !finished; ++i) {
        std::this_thread::sleep_for(std::chrono::milliseconds(10));
        finished = (executor->getTotalTasksExecuted() + executor->getTotalTasksFailed()) >= 1U;
    }

    EXPECT_TRUE(finished);
    EXPECT_EQ(controller->getTotalReallocations(), 1U);
    EXPECT_EQ(task->getAssignedEdgeId(), "E02");
}

TEST_F(FailureRecoveryIntegrationTest, RecoveredNodeAcceptsNewTasksAgain) {
    monitor->registerEdgeNode(makeEdge("E01"));
    monitor->simulateNodeFailure("E01");

    auto task = makeTask("T_AFTER_RECOVERY");
    auto failed_result = controller->allocateTaskNow(task);
    EXPECT_FALSE(failed_result.success);

    monitor->recoverNodeFromFailure("E01");
    auto recovered_result = controller->allocateTaskNow(makeTask("T_AFTER_RECOVERY_2"));
    EXPECT_TRUE(recovered_result.success);
    EXPECT_EQ(recovered_result.edge_id, "E01");
}

TEST_F(FailureRecoveryIntegrationTest, CascadingFailureOfAllNodesStopsNewAllocations) {
    monitor->registerEdgeNode(makeEdge("E01"));
    monitor->registerEdgeNode(makeEdge("E02"));
    monitor->simulateNodeFailure("E01");
    monitor->simulateNodeFailure("E02");

    const auto result = controller->allocateTaskNow(makeTask("T_NO_CAPACITY"));
    EXPECT_FALSE(result.success);
    EXPECT_EQ(monitor->getAvailableNodeCount(), 0U);
}

TEST_F(FailureRecoveryIntegrationTest, TasksOnHealthyNodeAreUnaffectedByAnotherNodesFailure) {
    monitor->registerEdgeNode(makeEdge("E01"));
    monitor->registerEdgeNode(makeEdge("E02"));
    executor->registerEdgeNode(monitor->getEdgeNode("E01"));
    executor->registerEdgeNode(monitor->getEdgeNode("E02"));

    auto healthy_task = makeTask("T_HEALTHY");
    healthy_task->setAssignedEdgeId("E02");
    monitor->getEdgeNode("E02")->enqueueTask(healthy_task);

    executor->start();
    monitor->simulateNodeFailure("E01");  // E02 (and its queued task) untouched

    bool finished = false;
    for (int i = 0; i < 200 && !finished; ++i) {
        std::this_thread::sleep_for(std::chrono::milliseconds(10));
        finished = (executor->getTotalTasksExecuted() + executor->getTotalTasksFailed()) >= 1U;
    }

    EXPECT_TRUE(finished);
    EXPECT_EQ(controller->getTotalReallocations(), 0U);  // nothing was on E01
}

TEST_F(FailureRecoveryIntegrationTest, MultipleQueuedTasksOnFailedNodeAllGetReallocated) {
    monitor->registerEdgeNode(makeEdge("E01"));
    monitor->registerEdgeNode(makeEdge("E02"));

    auto failed_edge = monitor->getEdgeNode("E01");
    for (int i = 0; i < 5; ++i) {
        auto t = makeTask("T_BATCH_" + std::to_string(i));
        t->setAssignedEdgeId("E01");
        failed_edge->enqueueTask(t);
    }

    monitor->simulateNodeFailure("E01");

    EXPECT_EQ(controller->getTotalReallocations(), 5U);
    EXPECT_FALSE(failed_edge->hasTasksInQueue());
    EXPECT_TRUE(monitor->getEdgeNode("E02")->hasTasksInQueue());
}
