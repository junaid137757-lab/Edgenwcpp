// INTEGRATION TESTS
//
// Unlike tests/unit/*.cpp (each isolates exactly one class), these
// wire together multiple REAL collaborators exactly as production code
// does (mirroring the pipeline in src/main.cpp's runExperiment(): a
// device generates data -> TaskManager creates a Task -> ResourceAllocator
// picks an edge -> TaskScheduler queues it -> TaskExecutor runs it ->
// DatabaseManager persists it -> MetricsCollector reports on it) and
// assert on the emergent, cross-component behavior rather than any one
// class's isolated contract.
#include <gtest/gtest.h>
#include "task/task_manager.h"
#include "resource/resource_allocator.h"
#include "scheduler/task_scheduler.h"
#include "executor/task_executor.h"
#include "metrics/metrics_collector.h"
#include "database/database_manager.h"
#include "iot_device/sensor_simulator.h"
#include "common/test_db_helper.h"
#include "common/test_factories.h"

#include <chrono>
#include <thread>

using test_factories::makeEdge;

namespace {

class FullPipelineIntegrationTest : public ::testing::Test {
protected:
    void SetUp() override {
        ensureTestDatabaseInitialized();
        DatabaseManager::getInstance().resetSimulationData();

        monitor = std::make_shared<ResourceMonitor>();
        monitor->registerEdgeNode(makeEdge("E01"));
        monitor->registerEdgeNode(makeEdge("E02"));

        task_manager = std::make_shared<TaskManager>();
        allocator = std::make_shared<ResourceAllocator>(
            monitor, ResourceAllocator::AllocationStrategy::MULTI_CONSTRAINT);
        scheduler = std::make_shared<TaskScheduler>(TaskScheduler::SchedulingStrategy::PRIORITY_BASED);
        executor = std::make_shared<TaskExecutor>(scheduler);

        for (const auto& id : {std::string("E01"), std::string("E02")}) {
            executor->registerEdgeNode(monitor->getEdgeNode(id));
        }
        executor->start();
    }

    void TearDown() override {
        if (executor) {
            executor->stop();
        }
    }

    // Generates one task from a device, allocates it, and schedules it —
    // the same three steps runExperiment() performs per cycle.
    std::shared_ptr<Task> generateAllocateAndSchedule(
        const std::string& device_id, const std::string& sensor_type) {
        // tasks.device_id has a FOREIGN KEY REFERENCES devices(device_id)
        // with foreign_keys=ON, so the device row must exist first —
        // INSERT OR REPLACE makes this safe to call every time.
        DatabaseManager::getInstance().saveDevice(device_id, sensor_type);

        auto task = task_manager->createTaskFromSensorData(
            device_id, sensor_type, json::object());
        DatabaseManager::getInstance().saveTask(task);

        const auto result = allocator->allocateTaskWithRetry(
            task, 20U, std::chrono::milliseconds(2));
        if (result.success) {
            scheduler->scheduleTask(monitor->getEdgeNode(result.edge_id), task);
            DatabaseManager::getInstance().saveAllocation(
                task->getTaskId(), result.edge_id, result.score);
        }
        return task;
    }

    bool waitUntilDrained(int max_wait_iterations = 200) {
        for (int i = 0; i < max_wait_iterations; ++i) {
            std::this_thread::sleep_for(std::chrono::milliseconds(10));
            if (!monitor->getEdgeNode("E01")->hasTasksInQueue() &&
                !monitor->getEdgeNode("E02")->hasTasksInQueue()) {
                return true;
            }
        }
        return false;
    }

    std::shared_ptr<ResourceMonitor> monitor;
    std::shared_ptr<TaskManager> task_manager;
    std::shared_ptr<ResourceAllocator> allocator;
    std::shared_ptr<TaskScheduler> scheduler;
    std::shared_ptr<TaskExecutor> executor;
};

}  // namespace

TEST_F(FullPipelineIntegrationTest, SingleTaskFlowsFromCreationThroughExecution) {
    auto task = generateAllocateAndSchedule("DEV1", "temperature");
    ASSERT_FALSE(task->getAssignedEdgeId().empty());

    ASSERT_TRUE(waitUntilDrained());
    EXPECT_GE(executor->getTotalTasksExecuted() + executor->getTotalTasksFailed(), 1U);

    const auto persisted = DatabaseManager::getInstance().getTask(task->getTaskId());
    ASSERT_NE(persisted, nullptr);
    EXPECT_EQ(persisted->getDeviceId(), "DEV1");
}

TEST_F(FullPipelineIntegrationTest, MultipleTasksAcrossMultipleDevicesAllComplete) {
    std::vector<std::shared_ptr<Task>> tasks;
    for (int i = 0; i < 10; ++i) {
        tasks.push_back(generateAllocateAndSchedule(
            "DEV" + std::to_string(i % 3), (i % 2 == 0) ? "temperature" : "humidity"));
    }

    ASSERT_TRUE(waitUntilDrained());
    EXPECT_GE(executor->getTotalTasksExecuted() + executor->getTotalTasksFailed(), 10U);
    EXPECT_EQ(task_manager->getTotalTasksCreated(), 10U);
}

TEST_F(FullPipelineIntegrationTest, AllocationHistoryIsQueryableAfterExecution) {
    generateAllocateAndSchedule("DEV1", "camera");
    ASSERT_TRUE(waitUntilDrained());

    const auto history = DatabaseManager::getInstance().getTaskAllocationHistory();
    ASSERT_FALSE(history.empty());
    EXPECT_TRUE(history[0]["success"].get<bool>());
}

TEST_F(FullPipelineIntegrationTest, MetricsCollectorReportsSaneValuesAfterARun) {
    for (int i = 0; i < 5; ++i) {
        generateAllocateAndSchedule("DEV1", "ultrasonic");
    }
    ASSERT_TRUE(waitUntilDrained());

    MetricsCollector collector(allocator, executor, monitor);
    const MetricsCollector::Snapshot snapshot = collector.collect(1.0);

    EXPECT_GE(snapshot.average_latency_ms, 0.0);
    EXPECT_GE(snapshot.task_success_rate_percent, 0.0);
    EXPECT_LE(snapshot.task_success_rate_percent, 100.0);
    EXPECT_GE(snapshot.throughput_tasks_per_second, 0.0);
}

TEST_F(FullPipelineIntegrationTest, MetricsCollectorJsonMatchesStructSnapshot) {
    generateAllocateAndSchedule("DEV1", "pressure");
    ASSERT_TRUE(waitUntilDrained());

    MetricsCollector collector(allocator, executor, monitor);
    const auto snapshot = collector.collect(1.0);
    const json as_json = collector.collectAsJson(1.0);

    EXPECT_DOUBLE_EQ(as_json["average_latency_ms"].get<double>(), snapshot.average_latency_ms);
    EXPECT_DOUBLE_EQ(as_json["task_success_rate_percent"].get<double>(), snapshot.task_success_rate_percent);
}

TEST_F(FullPipelineIntegrationTest, RealSensorDataFeedsTaskCreationEndToEnd) {
    // Uses a real IoTDevice subclass (rather than a hand-built json
    // payload) to confirm the whole chain accepts genuine sensor output.
    UltrasonicSensor sensor(IoTDevice::DeviceConfig{
        "US_INTEGRATION", IoTDevice::DeviceType::ULTRASONIC, 10.0, 0.1});
    const json reading = sensor.generateSensorData();

    auto task = task_manager->createTaskFromSensorData(
        sensor.getDeviceId(), sensor.getTypeString(), reading);
    const auto result = allocator->allocateTaskWithRetry(task, 20U, std::chrono::milliseconds(2));
    ASSERT_TRUE(result.success);
    scheduler->scheduleTask(monitor->getEdgeNode(result.edge_id), task);

    ASSERT_TRUE(waitUntilDrained());
    EXPECT_GE(executor->getTotalTasksExecuted() + executor->getTotalTasksFailed(), 1U);
}

TEST_F(FullPipelineIntegrationTest, TaskDatabaseStatusReflectsExecutionOutcome) {
    auto task = generateAllocateAndSchedule("DEV1", "temperature");
    ASSERT_TRUE(waitUntilDrained());

    const auto persisted = DatabaseManager::getInstance().getTask(task->getTaskId());
    ASSERT_NE(persisted, nullptr);
    // TaskExecutor updates DB status via DatabaseManager on completion —
    // it must have moved off its initial CREATED/QUEUED state.
    EXPECT_NE(persisted->getStatus(), Task::TaskStatus::CREATED);
}

TEST_F(FullPipelineIntegrationTest, HighPrioritySchedulerFavorsCriticalTasksUnderContention) {
    // Saturate E01/E02 capacity first so both new tasks queue up
    // together rather than executing immediately, giving the priority
    // scheduler something real to choose between.
    executor->stop();

    auto low = task_manager->createTaskFromSensorData("DEV1", "humidity", json::object());   // LOW priority
    auto critical = task_manager->createTaskFromSensorData("DEV1", "camera", json::object()); // CRITICAL priority

    auto edge = monitor->getEdgeNode("E01");
    scheduler->scheduleTask(edge, low);
    scheduler->scheduleTask(edge, critical);

    const auto next = scheduler->getNextTask(edge);
    ASSERT_NE(next, nullptr);
    EXPECT_EQ(next->getTaskId(), critical->getTaskId());
}
